﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace PraktikaPM04
{
    public partial class OKSWindow : UserControl
    {
        private readonly int _userId;
        private string _currentDateTime = DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss");
        private string _statusMessage = "Готово";
        private string _userFullName;

        public string CurrentDateTime
        {
            get => _currentDateTime;
            set
            {
                _currentDateTime = value;
                StatusMessage = $"Обновлено: {value}";
            }
        }

        public string StatusMessage
        {
            get => _statusMessage;
            set
            {
                _statusMessage = value;
                DataContext = this;
            }
        }

        public string UserFullName
        {
            get => _userFullName;
            set
            {
                _userFullName = value;
                DataContext = this;
            }
        }

        public OKSWindow(int userId)
        {
            _userId = userId;

            // Получаем полное имя пользователя
            string query = "SELECT FullName FROM Users WHERE UserID = @UserID";
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@UserID", _userId)
            };

            DataTable result = DatabaseHelper.ExecuteQuery(query, parameters);
            if (result.Rows.Count > 0)
            {
                UserFullName = result.Rows[0]["FullName"].ToString();
            }

            InitializeComponent();
            DataContext = this;

            LoadProjects();
            LoadSurveyRequests();
            LoadWorkActs();
            InitializeTimer();
        }

        private void InitializeTimer()
        {
            var timer = new System.Windows.Threading.DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += (s, e) => CurrentDateTime = DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss");
            timer.Start();
        }

        private void LoadProjects()
        {
            try
            {
                string query = @"
                SELECT 
                    p.ProjectID, 
                    p.ApplicationID, 
                    p.ProjectName,
                    CASE 
                        WHEN a.ApplicationTypeID = 1 AND a.Comments LIKE '%1 кат%' THEN '1 категория'
                        WHEN a.ApplicationTypeID = 1 AND (a.Comments LIKE '%2 кат%' OR a.Comments LIKE '%3 кат%') THEN '2-3 категория'
                        WHEN a.ApplicationTypeID = 1 AND a.Comments LIKE '%ИП%' THEN 'ИП'
                        ELSE 'Не определено'
                    END AS Category,
                    p.StartDate, 
                    p.PlannedEndDate AS DeadlineDate,
                    s.StatusName AS Status,
                    DATEDIFF(day, GETDATE(), p.PlannedEndDate) AS DaysLeft,
                    CASE 
                        WHEN DATEDIFF(day, GETDATE(), p.PlannedEndDate) <= 3 THEN 1
                        ELSE 0
                    END AS IsUrgent
                FROM ConstructionProjects p
                JOIN Applications a ON p.ApplicationID = a.ApplicationID
                JOIN ApplicationStatuses s ON a.StatusID = s.StatusID
                WHERE p.IsCompleted = 0
                ORDER BY p.PlannedEndDate ASC";

                DataTable projects = DatabaseHelper.ExecuteQuery(query);
                ProjectsGrid.ItemsSource = projects.DefaultView;

                ProjectsGrid.LoadingRow += (s, e) =>
                {
                    DataRowView rowView = e.Row.Item as DataRowView;
                    if (rowView != null && rowView["IsUrgent"] != DBNull.Value && (int)rowView["IsUrgent"] == 1)
                    {
                        e.Row.Background = System.Windows.Media.Brushes.LightPink;
                    }
                    else if (rowView != null && rowView["DaysLeft"] != DBNull.Value && (int)rowView["DaysLeft"] < 0)
                    {
                        e.Row.Background = System.Windows.Media.Brushes.LightCoral;
                    }
                };
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка загрузки проектов: {ex.Message}";
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LoadSurveyRequests()
        {
            try
            {
                string query = @"
                SELECT 
                    sr.RequestID, 
                    sr.ApplicationID, 
                    sr.RequestDate, 
                    sr.Status, 
                    sr.SurveyCompany,
                    DATEADD(day, 
                        CASE 
                            WHEN a.ApplicationTypeID = 1 AND a.Comments LIKE '%1 кат%' THEN 60
                            WHEN a.ApplicationTypeID = 1 AND (a.Comments LIKE '%2 кат%' OR a.Comments LIKE '%3 кат%') THEN 200
                            WHEN a.ApplicationTypeID = 1 AND a.Comments LIKE '%ИП%' THEN 240
                            ELSE 90
                        END, sr.RequestDate) AS CompletionDate
                FROM SurveyRequests sr
                JOIN Applications a ON sr.ApplicationID = a.ApplicationID
                WHERE sr.Status NOT IN ('Завершено', 'Отменено')
                ORDER BY sr.RequestDate DESC";

                DataTable requests = DatabaseHelper.ExecuteQuery(query);
                SurveyRequestsGrid.ItemsSource = requests.DefaultView;
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка загрузки запросов на изыскания: {ex.Message}";
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LoadWorkActs()
        {
            try
            {
                string query = @"
                SELECT 
                    g.ActID,
                    p.ProjectID,
                    g.ActNumber,
                    g.ActDate,
                    g.ConnectionDate,
                    CASE 
                        WHEN g.IsSigned = 1 THEN 'Подписан'
                        ELSE 'Не подписан'
                    END AS Status
                FROM GasConnectionActs g
                JOIN ConstructionProjects p ON g.ApplicationID = p.ApplicationID
                WHERE g.ActDate >= DATEADD(month, -3, GETDATE())
                ORDER BY g.ActDate DESC";

                DataTable acts = DatabaseHelper.ExecuteQuery(query);
                WorkActsGrid.ItemsSource = acts.DefaultView;
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка загрузки актов выполненных работ: {ex.Message}";
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void RefreshProjects(object sender, RoutedEventArgs e)
        {
            LoadProjects();
            StatusMessage = "Список проектов обновлен";
        }

        private void AcceptProject(object sender, RoutedEventArgs e)
        {
            if (ProjectsGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите проект для принятия в работу", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DataRowView row = (DataRowView)ProjectsGrid.SelectedItem;
            int projectId = (int)row["ProjectID"];
            int applicationId = (int)row["ApplicationID"];

            try
            {
                // Обновляем статус проекта
                string updateQuery = @"
                UPDATE ApplicationWorkflow 
                SET StatusID = 4, -- Одобрена
                    Comments = 'Принято в работу специалистом ОКС',
                    ModificationDate = GETDATE()
                WHERE ApplicationID = @ApplicationID 
                AND ToDepartmentID = 4 -- ОКС
                AND IsCompleted = 0";

                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@ApplicationID", applicationId)
                };

                DatabaseHelper.ExecuteNonQuery(updateQuery, parameters);
                LoadProjects();
                StatusMessage = $"Проект {projectId} принят в работу";
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка принятия проекта: {ex.Message}";
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void RequestRevision(object sender, RoutedEventArgs e)
        {
            if (ProjectsGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите проект для запроса доработки", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DataRowView row = (DataRowView)ProjectsGrid.SelectedItem;
            int projectId = (int)row["ProjectID"];
            int applicationId = (int)row["ApplicationID"];

            // Здесь можно добавить диалог для ввода комментария
            string comment = "Требуется доработка проекта";

            try
            {
                string query = @"
                UPDATE ApplicationWorkflow 
                SET StatusID = 5, -- Отказ
                    Comments = @Comment,
                    ModificationDate = GETDATE()
                WHERE ApplicationID = @ApplicationID 
                AND ToDepartmentID = 4 -- ОКС
                AND IsCompleted = 0";

                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@ApplicationID", applicationId),
                    new SqlParameter("@Comment", comment)
                };

                DatabaseHelper.ExecuteNonQuery(query, parameters);
                LoadProjects();
                StatusMessage = $"Запрошена доработка проекта {projectId}";
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка запроса доработки: {ex.Message}";
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CompleteProject(object sender, RoutedEventArgs e)
        {
            if (ProjectsGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите проект для завершения", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DataRowView row = (DataRowView)ProjectsGrid.SelectedItem;
            int projectId = (int)row["ProjectID"];
            int applicationId = (int)row["ApplicationID"];

            try
            {
                // Обновляем статус проекта
                string updateQuery = @"
                UPDATE ConstructionProjects 
                SET IsCompleted = 1,
                    CompletionDate = GETDATE()
                WHERE ProjectID = @ProjectID";

                SqlParameter[] updateParams = new SqlParameter[]
                {
                    new SqlParameter("@ProjectID", projectId)
                };

                DatabaseHelper.ExecuteNonQuery(updateQuery, updateParams);

                // Обновляем workflow
                string workflowQuery = @"
                UPDATE ApplicationWorkflow 
                SET IsCompleted = 1,
                    CompletionDate = GETDATE()
                WHERE ApplicationID = @ApplicationID 
                AND ToDepartmentID = 4 -- ОКС
                AND IsCompleted = 0";

                SqlParameter[] workflowParams = new SqlParameter[]
                {
                    new SqlParameter("@ApplicationID", applicationId)
                };

                DatabaseHelper.ExecuteNonQuery(workflowQuery, workflowParams);

                // Создаем workflow для ЦДС
                string newWorkflowQuery = @"
                INSERT INTO ApplicationWorkflow (ApplicationID, FromDepartmentID, ToDepartmentID, StatusID, 
                                              ActionDate, Comments, ProcessingDeadline, DeadlineDate)
                VALUES (@ApplicationID, 4, 6, 4, GETDATE(), 'Проект завершен, требуется пуск газа', 5, DATEADD(day, 5, GETDATE()))";

                SqlParameter[] newWorkflowParams = new SqlParameter[]
                {
                    new SqlParameter("@ApplicationID", applicationId)
                };

                DatabaseHelper.ExecuteNonQuery(newWorkflowQuery, newWorkflowParams);

                LoadProjects();
                StatusMessage = $"Проект {projectId} завершен и передан в ЦДС";
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка завершения проекта: {ex.Message}";
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ViewProject_Click(object sender, RoutedEventArgs e)
        {
            if (ProjectsGrid.SelectedItem == null) return;

            DataRowView row = (DataRowView)ProjectsGrid.SelectedItem;
            int projectId = (int)row["ProjectID"];

            // Здесь можно реализовать просмотр проекта
            MessageBox.Show($"Просмотр проекта ID: {projectId}", "Просмотр проекта", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void RefreshSurveys(object sender, RoutedEventArgs e)
        {
            LoadSurveyRequests();
            StatusMessage = "Список запросов на изыскания обновлен";
        }

        private void CreateSurveyTask(object sender, RoutedEventArgs e)
        {
            if (SurveyRequestsGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите запрос для создания ТЗ", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DataRowView row = (DataRowView)SurveyRequestsGrid.SelectedItem;
            int requestId = (int)row["RequestID"];

            // Диалог создания ТЗ на изыскания
            var dialog = new SurveyTaskDialog();
            if (dialog.ShowDialog() == true)
            {
                try
                {
                    string query = @"
                    UPDATE SurveyRequests 
                    SET Status = 'ТЗ подготовлено',
                        SurveyCompany = @Company
                    WHERE RequestID = @RequestID";

                    SqlParameter[] parameters = new SqlParameter[]
                    {
                        new SqlParameter("@RequestID", requestId),
                        new SqlParameter("@Company", dialog.CompanyName)
                    };

                    DatabaseHelper.ExecuteNonQuery(query, parameters);
                    LoadSurveyRequests();
                    StatusMessage = "Техническое задание на изыскания создано";
                }
                catch (Exception ex)
                {
                    StatusMessage = $"Ошибка создания ТЗ: {ex.Message}";
                    MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void SendSurveyToContractor(object sender, RoutedEventArgs e)
        {
            if (SurveyRequestsGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите запрос для отправки исполнителю", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DataRowView row = (DataRowView)SurveyRequestsGrid.SelectedItem;
            int requestId = (int)row["RequestID"];
            int applicationId = (int)row["ApplicationID"];

            try
            {
                // Обновляем статус запроса
                string updateQuery = @"
                UPDATE SurveyRequests 
                SET Status = 'Отправлено исполнителю'
                WHERE RequestID = @RequestID";

                SqlParameter[] updateParams = new SqlParameter[]
                {
                    new SqlParameter("@RequestID", requestId)
                };

                DatabaseHelper.ExecuteNonQuery(updateQuery, updateParams);

                LoadSurveyRequests();
                StatusMessage = $"Запрос {requestId} отправлен исполнителю";
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка отправки запроса: {ex.Message}";
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void RefreshWorkActs(object sender, RoutedEventArgs e)
        {
            LoadWorkActs();
            StatusMessage = "Список актов выполненных работ обновлен";
        }

        private void CreateWorkAct(object sender, RoutedEventArgs e)
        {
            if (ProjectsGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите проект для создания акта", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DataRowView projectRow = (DataRowView)ProjectsGrid.SelectedItem;
            int projectId = (int)projectRow["ProjectID"];
            int applicationId = (int)projectRow["ApplicationID"];

            // Диалог создания акта выполненных работ
            var dialog = new WorkActDialog();
            if (dialog.ShowDialog() == true)
            {
                try
                {
                    // Получаем следующий номер акта
                    string maxNumberQuery = @"
                    SELECT ISNULL(MAX(CAST(SUBSTRING(ActNumber, 5, LEN(ActNumber)-4) AS INT), 0) + 1 
                    FROM GasConnectionActs 
                    WHERE YEAR(ActDate) = YEAR(GETDATE())";

                    int nextNumber = Convert.ToInt32(DatabaseHelper.ExecuteScalar(maxNumberQuery, null));

                    string actNumber = $"АПГ-{DateTime.Now.Year}-{nextNumber.ToString("D3")}";

                    // Добавляем новый акт
                    string insertQuery = @"
                    INSERT INTO GasConnectionActs (ApplicationID, ActNumber, ActDate, ConnectionDate)
                    VALUES (@ApplicationID, @ActNumber, @ActDate, @ConnectionDate)";

                    SqlParameter[] insertParams = new SqlParameter[]
                    {
                        new SqlParameter("@ApplicationID", applicationId),
                        new SqlParameter("@ActNumber", actNumber),
                        new SqlParameter("@ActDate", dialog.ActDate),
                        new SqlParameter("@ConnectionDate", dialog.ConnectionDate)
                    };

                    DatabaseHelper.ExecuteNonQuery(insertQuery, insertParams);
                    LoadWorkActs();
                    StatusMessage = "Акт выполненных работ создан";
                }
                catch (Exception ex)
                {
                    StatusMessage = $"Ошибка создания акта: {ex.Message}";
                    MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void SendActToPTO(object sender, RoutedEventArgs e)
        {
            if (WorkActsGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите акт для отправки в ПТО", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DataRowView row = (DataRowView)WorkActsGrid.SelectedItem;
            int actId = (int)row["ActID"];
            int projectId = (int)row["ProjectID"];

            try
            {
                // Обновляем статус акта
                string updateQuery = @"
                UPDATE GasConnectionActs 
                SET IsSigned = 1,
                    SignDate = GETDATE()
                WHERE ActID = @ActID";

                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@ActID", actId)
                };

                DatabaseHelper.ExecuteNonQuery(updateQuery, parameters);

                // Создаем workflow для ПТО
                string workflowQuery = @"
                INSERT INTO ApplicationWorkflow (ApplicationID, FromDepartmentID, ToDepartmentID, StatusID, 
                                              ActionDate, Comments, ProcessingDeadline, DeadlineDate)
                SELECT 
                    ApplicationID, 
                    4, -- ОКС
                    2, -- ПТО
                    4, -- Одобрена
                    GETDATE(), 
                    'Акт выполненных работ готов к подписанию', 
                    3, 
                    DATEADD(day, 3, GETDATE())
                FROM ConstructionProjects 
                WHERE ProjectID = @ProjectID";

                SqlParameter[] workflowParams = new SqlParameter[]
                {
                    new SqlParameter("@ProjectID", projectId)
                };

                DatabaseHelper.ExecuteNonQuery(workflowQuery, workflowParams);

                LoadWorkActs();
                StatusMessage = $"Акт {actId} отправлен в ПТО для подписания";
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка отправки акта: {ex.Message}";
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ExportToExcel(object sender, RoutedEventArgs e)
        {
            try
            {
                // Здесь можно реализовать экспорт данных в Excel
                MessageBox.Show("Экспорт в Excel выполнен успешно", "Экспорт данных", MessageBoxButton.OK, MessageBoxImage.Information);
                StatusMessage = "Данные экспортированы в Excel";
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка экспорта в Excel: {ex.Message}";
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}