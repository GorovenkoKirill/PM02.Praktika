﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Net.NetworkInformation;
using System.Windows;
using System.Windows.Controls;
using System.Xml.Linq;
using Microsoft.Win32;

namespace PraktikaPM04
{
    public partial class ProjectDocumentationView : UserControl
    {
        private int currentUserId;
        private DataRowView selectedProject;

        public ProjectDocumentationView(int userId)
        {
            InitializeComponent();
            currentUserId = userId;
            LoadProjects();
        }

        private void LoadProjects()
        {
            try
            {
                string query = @"
                    SELECT 
                        a.ApplicationID,
                        c.FullName AS ClientName,
                        a.ObjectName,
                        ast.StatusName,
                        aw.DeadlineDate AS Deadline,
                        tc.ConditionsText AS TechConditions,
                        cp.ProjectCost AS EstimateCost,
                        cp.StartDate,
                        cp.PlannedEndDate,
                        cp.ActualEndDate
                    FROM Applications a
                    JOIN Clients c ON a.ClientID = c.ClientID
                    JOIN ApplicationStatuses ast ON a.StatusID = ast.StatusID
                    LEFT JOIN ApplicationWorkflow aw ON a.ApplicationID = aw.ApplicationID 
                        AND aw.IsCompleted = 0 AND aw.ToDepartmentID = 3 -- ПСО
                    LEFT JOIN TechnicalConditions tc ON a.ApplicationID = tc.ApplicationID
                    LEFT JOIN ConstructionProjects cp ON a.ApplicationID = cp.ApplicationID
                    WHERE a.ApplicationTypeID IN (1, 2) -- Заявки на подключение и ТУ
                    ORDER BY a.ApplicationID DESC";

                DataTable projects = DatabaseHelper.ExecuteQuery(query);
                dgProjects.ItemsSource = projects.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке проектов: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ProjectsGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dgProjects.SelectedItem == null) return;

            selectedProject = (DataRowView)dgProjects.SelectedItem;
            DisplayProjectDetails(selectedProject);
            LoadProjectDocuments(selectedProject["ApplicationID"].ToString());
            LoadEstimateItems(selectedProject["ApplicationID"].ToString());
            LoadWorkflowHistory(selectedProject["ApplicationID"].ToString());
        }

        private void DisplayProjectDetails(DataRowView project)
        {
            tbAppNumber.Text = project["ApplicationID"].ToString();
            tbClient.Text = project["ClientName"].ToString();
            tbObject.Text = project["ObjectName"].ToString();
            tbStatus.Text = project["StatusName"].ToString();
            tbDeadline.Text = project["Deadline"] != DBNull.Value ?
                Convert.ToDateTime(project["Deadline"]).ToString("dd.MM.yyyy") : "Не указан";
            tbTechConditions.Text = project["TechConditions"] != DBNull.Value ?
                project["TechConditions"].ToString() : "Не указаны";
            tbEstimateCost.Text = project["EstimateCost"] != DBNull.Value ?
                Convert.ToDecimal(project["EstimateCost"]).ToString("N2") + " руб." : "Не рассчитана";
            tbStartDate.Text = project["StartDate"] != DBNull.Value ?
                Convert.ToDateTime(project["StartDate"]).ToString("dd.MM.yyyy") : "Не начат";
            tbEndDate.Text = project["ActualEndDate"] != DBNull.Value ?
                Convert.ToDateTime(project["ActualEndDate"]).ToString("dd.MM.yyyy") :
                (project["PlannedEndDate"] != DBNull.Value ?
                    "Планируется: " + Convert.ToDateTime(project["PlannedEndDate"]).ToString("dd.MM.yyyy") :
                    "Не определено");
        }

        private void LoadProjectDocuments(string applicationId)
        {
            try
            {
                string query = @"
                    SELECT 
                        d.DocumentID,
                        dt.TypeName AS DocumentTypeName,
                        d.FilePath,
                        d.IsAttached,
                        d.CreationDate
                    FROM Documents d
                    JOIN DocumentTypes dt ON d.DocumentTypeID = dt.DocumentTypeID
                    WHERE d.ApplicationID = @ApplicationID
                    ORDER BY d.CreationDate DESC";

                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@ApplicationID", SqlDbType.Int) { Value = Convert.ToInt32(applicationId) }
                };

                DataTable documents = DatabaseHelper.ExecuteQuery(query, parameters);
                dgDocuments.ItemsSource = documents.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке документов: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LoadEstimateItems(string applicationId)
        {
            try
            {
                string query = @"
                    SELECT 
                        ItemNumber,
                        ItemName,
                        Unit,
                        Quantity,
                        UnitPrice
                    FROM EstimateItems
                    WHERE ApplicationID = @ApplicationID
                    ORDER BY ItemNumber";

                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@ApplicationID", SqlDbType.Int) { Value = Convert.ToInt32(applicationId) }
                };

                DataTable items = DatabaseHelper.ExecuteQuery(query, parameters);
                dgEstimateItems.ItemsSource = items.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке позиций сметы: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LoadWorkflowHistory(string applicationId)
        {
            try
            {
                string query = @"
                    SELECT 
                        aw.ActionDate,
                        d.DepartmentName,
                        ast.StatusName,
                        aw.Comments
                    FROM ApplicationWorkflow aw
                    LEFT JOIN Departments d ON aw.ToDepartmentID = d.DepartmentID
                    JOIN ApplicationStatuses ast ON aw.StatusID = ast.StatusID
                    WHERE aw.ApplicationID = @ApplicationID
                    ORDER BY aw.ActionDate DESC";

                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@ApplicationID", SqlDbType.Int) { Value = Convert.ToInt32(applicationId) }
                };

                DataTable workflow = DatabaseHelper.ExecuteQuery(query, parameters);
                dgWorkflow.ItemsSource = workflow.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке истории обработки: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string query = @"
                    SELECT 
                        a.ApplicationID,
                        c.FullName AS ClientName,
                        a.ObjectName,
                        ast.StatusName,
                        aw.DeadlineDate AS Deadline,
                        tc.ConditionsText AS TechConditions,
                        cp.ProjectCost AS EstimateCost,
                        cp.StartDate,
                        cp.PlannedEndDate,
                        cp.ActualEndDate
                    FROM Applications a
                    JOIN Clients c ON a.ClientID = c.ClientID
                    JOIN ApplicationStatuses ast ON a.StatusID = ast.StatusID
                    LEFT JOIN ApplicationWorkflow aw ON a.ApplicationID = aw.ApplicationID 
                        AND aw.IsCompleted = 0 AND aw.ToDepartmentID = 3 -- ПСО
                    LEFT JOIN TechnicalConditions tc ON a.ApplicationID = tc.ApplicationID
                    LEFT JOIN ConstructionProjects cp ON a.ApplicationID = cp.ApplicationID
                    WHERE a.ApplicationTypeID IN (1, 2) -- Заявки на подключение и ТУ";

                string filters = "";
                SqlParameter[] parameters = null;

                if (!string.IsNullOrWhiteSpace(txtApplicationNumber.Text))
                {
                    filters += " AND a.ApplicationID = @ApplicationID";
                    Array.Resize(ref parameters, parameters == null ? 1 : parameters.Length + 1);
                    parameters[parameters.Length - 1] = new SqlParameter("@ApplicationID", SqlDbType.Int)
                    { Value = Convert.ToInt32(txtApplicationNumber.Text) };
                }

                if (!string.IsNullOrWhiteSpace(txtClientName.Text))
                {
                    filters += " AND c.FullName LIKE @ClientName";
                    Array.Resize(ref parameters, parameters == null ? 1 : parameters.Length + 1);
                    parameters[parameters.Length - 1] = new SqlParameter("@ClientName", SqlDbType.NVarChar)
                    { Value = $"%{txtClientName.Text}%" };
                }

                if (cmbStatus.SelectedIndex > 0)
                {
                    string statusFilter = cmbStatus.SelectedItem.ToString();
                    switch (statusFilter)
                    {
                        case "На рассмотрении":
                            filters += " AND ast.StatusID = 1"; // На регистрации
                            break;
                        case "В работе":
                            filters += " AND ast.StatusID IN (2, 3)"; // В работе, Рассматривается
                            break;
                        case "Завершено":
                            filters += " AND ast.StatusID = 6"; // Готово
                            break;
                        case "Отклонено":
                            filters += " AND ast.StatusID IN (5, 7)"; // Отказ, Аннулировано
                            break;
                    }
                }

                query += filters + " ORDER BY a.ApplicationID DESC";

                DataTable projects = DatabaseHelper.ExecuteQuery(query, parameters);
                dgProjects.ItemsSource = projects.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при поиске проектов: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ResetButton_Click(object sender, RoutedEventArgs e)
        {
            txtApplicationNumber.Text = "";
            txtClientName.Text = "";
            cmbStatus.SelectedIndex = 0;
            LoadProjects();
        }

        private void AddDocument_Click(object sender, RoutedEventArgs e)
        {
            if (selectedProject == null)
            {
                MessageBox.Show("Выберите проект для добавления документа", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Документы (*.pdf;*.doc;*.docx;*.xls;*.xlsx)|*.pdf;*.doc;*.docx;*.xls;*.xlsx";

            if (openFileDialog.ShowDialog() == true)
            {
                try
                {
                    // В реальном приложении здесь должна быть логика загрузки файла на сервер
                    string fileName = Path.GetFileName(openFileDialog.FileName);
                    string filePath = $"\\\\server\\docs\\app{selectedProject["ApplicationID"]}\\{fileName}";

                    string query = @"
                        INSERT INTO Documents (ApplicationID, DocumentTypeID, FilePath, IsAttached, CreationDate)
                        VALUES (@ApplicationID, @DocumentTypeID, @FilePath, 1, GETDATE())";

                    SqlParameter[] parameters = new SqlParameter[]
                    {
                        new SqlParameter("@ApplicationID", SqlDbType.Int) { Value = Convert.ToInt32(selectedProject["ApplicationID"]) },
                        new SqlParameter("@DocumentTypeID", SqlDbType.Int) { Value = 5 }, // Проектная документация
                        new SqlParameter("@FilePath", SqlDbType.NVarChar) { Value = filePath }
                    };

                    int result = DatabaseHelper.ExecuteNonQuery(query, parameters);

                    if (result > 0)
                    {
                        MessageBox.Show("Документ успешно добавлен", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                        LoadProjectDocuments(selectedProject["ApplicationID"].ToString());
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при добавлении документа: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void DeleteDocument_Click(object sender, RoutedEventArgs e)
        {
            if (dgDocuments.SelectedItem == null)
            {
                MessageBox.Show("Выберите документ для удаления", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DataRowView selectedDoc = (DataRowView)dgDocuments.SelectedItem;

            if (MessageBox.Show("Вы уверены, что хотите удалить выбранный документ?", "Подтверждение",
                MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    string query = "DELETE FROM Documents WHERE DocumentID = @DocumentID";
                    SqlParameter[] parameters = new SqlParameter[]
                    {
                        new SqlParameter("@DocumentID", SqlDbType.Int) { Value = Convert.ToInt32(selectedDoc["DocumentID"]) }
                    };

                    int result = DatabaseHelper.ExecuteNonQuery(query, parameters);

                    if (result > 0)
                    {
                        MessageBox.Show("Документ успешно удален", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                        LoadProjectDocuments(selectedProject["ApplicationID"].ToString());
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при удалении документа: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void ViewDocument_Click(object sender, RoutedEventArgs e)
        {
            if (dgDocuments.SelectedItem == null) return;

            DataRowView selectedDoc = (DataRowView)dgDocuments.SelectedItem;
            string filePath = selectedDoc["FilePath"].ToString();

            try
            {
                // В реальном приложении здесь должна быть логика открытия файла
                System.Diagnostics.Process.Start(filePath);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Не удалось открыть документ: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void AddEstimateItem_Click(object sender, RoutedEventArgs e)
        {
            if (selectedProject == null)
            {
                MessageBox.Show("Выберите проект для добавления позиции сметы", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var dialog = new EstimateItemDialog();
            if (dialog.ShowDialog() == true)
            {
                try
                {
                    string query = @"
                        INSERT INTO EstimateItems (ApplicationID, ItemNumber, ItemName, Unit, Quantity, UnitPrice)
                        VALUES (@ApplicationID, @ItemNumber, @ItemName, @Unit, @Quantity, @UnitPrice)";

                    SqlParameter[] parameters = new SqlParameter[]
                    {
                        new SqlParameter("@ApplicationID", SqlDbType.Int) { Value = Convert.ToInt32(selectedProject["ApplicationID"]) },
                        new SqlParameter("@ItemNumber", SqlDbType.Int) { Value = dialog.ItemNumber },
                        new SqlParameter("@ItemName", SqlDbType.NVarChar) { Value = dialog.ItemName },
                        new SqlParameter("@Unit", SqlDbType.NVarChar) { Value = dialog.Unit },
                        new SqlParameter("@Quantity", SqlDbType.Decimal) { Value = dialog.Quantity },
                        new SqlParameter("@UnitPrice", SqlDbType.Decimal) { Value = dialog.UnitPrice }
                    };

                    int result = DatabaseHelper.ExecuteNonQuery(query, parameters);

                    if (result > 0)
                    {
                        MessageBox.Show("Позиция сметы успешно добавлена", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                        LoadEstimateItems(selectedProject["ApplicationID"].ToString());
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при добавлении позиции сметы: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void DeleteEstimateItem_Click(object sender, RoutedEventArgs e)
        {
            if (dgEstimateItems.SelectedItem == null)
            {
                MessageBox.Show("Выберите позицию сметы для удаления", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DataRowView selectedItem = (DataRowView)dgEstimateItems.SelectedItem;

            if (MessageBox.Show("Вы уверены, что хотите удалить выбранную позицию сметы?", "Подтверждение",
                MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    string query = @"
                        DELETE FROM EstimateItems 
                        WHERE ApplicationID = @ApplicationID AND ItemNumber = @ItemNumber";

                    SqlParameter[] parameters = new SqlParameter[]
                    {
                        new SqlParameter("@ApplicationID", SqlDbType.Int) { Value = Convert.ToInt32(selectedProject["ApplicationID"]) },
                        new SqlParameter("@ItemNumber", SqlDbType.Int) { Value = Convert.ToInt32(selectedItem["ItemNumber"]) }
                    };

                    int result = DatabaseHelper.ExecuteNonQuery(query, parameters);

                    if (result > 0)
                    {
                        MessageBox.Show("Позиция сметы успешно удалена", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                        LoadEstimateItems(selectedProject["ApplicationID"].ToString());
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при удалении позиции сметы: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void ExportToExcel_Click(object sender, RoutedEventArgs e)
        {
            if (selectedProject == null)
            {
                MessageBox.Show("Выберите проект для экспорта сметы", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Excel файлы (*.xlsx)|*.xlsx";
            saveFileDialog.FileName = $"Смета_проекта_{selectedProject["ApplicationID"]}.xlsx";

            if (saveFileDialog.ShowDialog() == true)
            {
                try
                {
                    // В реальном приложении здесь должна быть логика экспорта в Excel
                    MessageBox.Show("Экспорт в Excel успешно завершен", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при экспорте в Excel: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void AcceptForWork_Click(object sender, RoutedEventArgs e)
        {
            if (selectedProject == null)
            {
                MessageBox.Show("Выберите проект для принятия в работу", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (MessageBox.Show("Принять выбранный проект в работу?", "Подтверждение",
                MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    // Обновление статуса заявки
                    string updateQuery = @"
                        UPDATE Applications 
                        SET StatusID = 2, -- В работе
                            ModificationDate = GETDATE()
                        WHERE ApplicationID = @ApplicationID";

                    // Добавление записи в workflow
                    string workflowQuery = @"
                        INSERT INTO ApplicationWorkflow (ApplicationID, FromDepartmentID, ToDepartmentID, StatusID, 
                            ActionDate, Comments, ProcessingDeadline, DeadlineDate, IsCompleted)
                        VALUES (@ApplicationID, NULL, 3, 2, GETDATE(), 'Проект принят в работу ПСО', 14, 
                            DATEADD(day, 14, GETDATE()), 0)";

                    SqlParameter[] parameters = new SqlParameter[]
                    {
                        new SqlParameter("@ApplicationID", SqlDbType.Int) { Value = Convert.ToInt32(selectedProject["ApplicationID"]) }
                    };

                    int updateResult = DatabaseHelper.ExecuteNonQuery(updateQuery, parameters);
                    int workflowResult = DatabaseHelper.ExecuteNonQuery(workflowQuery, parameters);

                    if (updateResult > 0 && workflowResult > 0)
                    {
                        MessageBox.Show("Проект успешно принят в работу", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                        LoadProjects();
                        LoadWorkflowHistory(selectedProject["ApplicationID"].ToString());
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при принятии проекта в работу: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void CompleteProject_Click(object sender, RoutedEventArgs e)
        {
            if (selectedProject == null)
            {
                MessageBox.Show("Выберите проект для завершения", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (MessageBox.Show("Завершить выбранный проект?", "Подтверждение",
                MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    // Обновление статуса заявки
                    string updateQuery = @"
                        UPDATE Applications 
                        SET StatusID = 6, -- Готово
                            CompletionDate = GETDATE(),
                            ModificationDate = GETDATE()
                        WHERE ApplicationID = @ApplicationID";

                    // Обновление workflow
                    string workflowUpdateQuery = @"
                        UPDATE ApplicationWorkflow 
                        SET IsCompleted = 1,
                            CompletionDate = GETDATE()
                        WHERE ApplicationID = @ApplicationID AND IsCompleted = 0";

                    // Добавление записи в workflow
                    string workflowInsertQuery = @"
                        INSERT INTO ApplicationWorkflow (ApplicationID, FromDepartmentID, ToDepartmentID, StatusID, 
                            ActionDate, Comments, ProcessingDeadline, DeadlineDate, IsCompleted, CompletionDate)
                        VALUES (@ApplicationID, 3, 4, 6, GETDATE(), 'Проект завершен ПСО', 0, NULL, 1, GETDATE())";

                    // Создание проекта строительства (если еще не создан)
                    string projectQuery = @"
                        IF NOT EXISTS (SELECT 1 FROM ConstructionProjects WHERE ApplicationID = @ApplicationID)
                        BEGIN
                            INSERT INTO ConstructionProjects (ApplicationID, ProjectName, ProjectCost, 
                                StartDate, PlannedEndDate, ActualEndDate, IsCompleted, CompletionDate)
                            VALUES (@ApplicationID, @ProjectName, @ProjectCost, 
                                @StartDate, @PlannedEndDate, GETDATE(), 1, GETDATE())
                        END
                        ELSE
                        BEGIN
                            UPDATE ConstructionProjects
                            SET ActualEndDate = GETDATE(),
                                IsCompleted = 1,
                                CompletionDate = GETDATE()
                            WHERE ApplicationID = @ApplicationID
                        END";

                    SqlParameter[] parameters = new SqlParameter[]
                    {
                        new SqlParameter("@ApplicationID", SqlDbType.Int) { Value = Convert.ToInt32(selectedProject["ApplicationID"]) },
                        new SqlParameter("@ProjectName", SqlDbType.NVarChar) { Value = $"Проект {selectedProject["ApplicationID"]}" },
                        new SqlParameter("@ProjectCost", SqlDbType.Decimal) { Value = CalculateTotalEstimate(selectedProject["ApplicationID"].ToString()) },
                        new SqlParameter("@StartDate", SqlDbType.Date) { Value = DateTime.Today.AddDays(-14) },
                        new SqlParameter("@PlannedEndDate", SqlDbType.Date) { Value = DateTime.Today }
                    };

                    int updateResult = DatabaseHelper.ExecuteNonQuery(updateQuery, parameters);
                    int workflowUpdateResult = DatabaseHelper.ExecuteNonQuery(workflowUpdateQuery, parameters);
                    int workflowInsertResult = DatabaseHelper.ExecuteNonQuery(workflowInsertQuery, parameters);
                    int projectResult = DatabaseHelper.ExecuteNonQuery(projectQuery, parameters);

                    if (updateResult > 0 && workflowUpdateResult >= 0 && workflowInsertResult > 0 && projectResult > 0)
                    {
                        MessageBox.Show("Проект успешно завершен", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                        LoadProjects();
                        LoadWorkflowHistory(selectedProject["ApplicationID"].ToString());
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при завершении проекта: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private decimal CalculateTotalEstimate(string applicationId)
        {
            try
            {
                string query = "SELECT SUM(Quantity * UnitPrice) FROM EstimateItems WHERE ApplicationID = @ApplicationID";
                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@ApplicationID", SqlDbType.Int) { Value = Convert.ToInt32(applicationId) }
                };

                object result = DatabaseHelper.ExecuteScalar(query, parameters);
                return result != DBNull.Value ? Convert.ToDecimal(result) : 0;
            }
            catch
            {
                return 0;
            }
        }

        private void RejectProject_Click(object sender, RoutedEventArgs e)
        {
            if (selectedProject == null)
            {
                MessageBox.Show("Выберите проект для отклонения", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var reasonDialog = new RejectReasonDialog();
            if (reasonDialog.ShowDialog() == true)
            {
                try
                {
                    // Обновление статуса заявки
                    string updateQuery = @"
                        UPDATE Applications 
                        SET StatusID = 5, -- Отказ
                            ModificationDate = GETDATE(),
                            Comments = @Comments
                        WHERE ApplicationID = @ApplicationID";

                    // Обновление workflow
                    string workflowUpdateQuery = @"
                        UPDATE ApplicationWorkflow 
                        SET IsCompleted = 1,
                            CompletionDate = GETDATE()
                        WHERE ApplicationID = @ApplicationID AND IsCompleted = 0";

                    // Добавление записи в workflow
                    string workflowInsertQuery = @"
                        INSERT INTO ApplicationWorkflow (ApplicationID, FromDepartmentID, ToDepartmentID, StatusID, 
                            ActionDate, Comments, ProcessingDeadline, DeadlineDate, IsCompleted, CompletionDate)
                        VALUES (@ApplicationID, 3, 1, 5, GETDATE(), @Comments, 0, NULL, 1, GETDATE())";

                    SqlParameter[] parameters = new SqlParameter[]
                    {
                        new SqlParameter("@ApplicationID", SqlDbType.Int) { Value = Convert.ToInt32(selectedProject["ApplicationID"]) },
                        new SqlParameter("@Comments", SqlDbType.NVarChar) { Value = reasonDialog.Reason }
                    };

                    int updateResult = DatabaseHelper.ExecuteNonQuery(updateQuery, parameters);
                    int workflowUpdateResult = DatabaseHelper.ExecuteNonQuery(workflowUpdateQuery, parameters);
                    int workflowInsertResult = DatabaseHelper.ExecuteNonQuery(workflowInsertQuery, parameters);

                    if (updateResult > 0 && workflowUpdateResult >= 0 && workflowInsertResult > 0)
                    {
                        MessageBox.Show("Проект успешно отклонен", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                        LoadProjects();
                        LoadWorkflowHistory(selectedProject["ApplicationID"].ToString());
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при отклонении проекта: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            
        }
    }
}
