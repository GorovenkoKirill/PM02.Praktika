﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace PraktikaPM04
{
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        private readonly int _userId;
        private object _currentView;
        private string _statusMessage = "Готово";
        private string _currentDateTime = DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss");

        public int UserId => _userId;
        public string UserFullName { get; }
        public string RoleName { get; }

        public object CurrentView
        {
            get => _currentView;
            set
            {
                _currentView = value;
                OnPropertyChanged(nameof(CurrentView));
            }
        }

        public string StatusMessage
        {
            get => _statusMessage;
            set
            {
                _statusMessage = value;
                OnPropertyChanged(nameof(StatusMessage));
            }
        }

        public string CurrentDateTime
        {
            get => _currentDateTime;
            set
            {
                _currentDateTime = value;
                OnPropertyChanged(nameof(CurrentDateTime));
            }
        }

        public ICommand NavigateCommand { get; }

        public List<MenuItem> MenuItems { get; } = new List<MenuItem>();

        public MainWindow(int userId, string fullName, string roleName)
        {
            _userId = userId;
            UserFullName = fullName;
            RoleName = roleName;

            InitializeComponent();
            DataContext = this;

            NavigateCommand = new RelayCommand(NavigateToView);

            InitializeMenuBasedOnRole();
            InitializeTimer();

            // Загружаем начальный вид
            if (MenuItems.Count > 0)
            {
                NavigateToView(MenuItems[0].ViewType);
            }
        }

        private void InitializeMenuBasedOnRole()
        {
            switch (RoleName)
            {
                case "Оператор СРЗ": // Служба по работе с заявителями
                    MenuItems.AddRange(new[]
                    {
                new MenuItem("Регистрация заявки", typeof(SRZ.RegisterApplicationView)),
                new MenuItem("Просмотр заявок", typeof(SRZ.ViewApplicationsView)),
                new MenuItem("Уведомления", typeof(SRZ.NotificationsView)),
                new MenuItem("Отчетность", typeof(SRZ.ReportsView))
            });
                    break;

                case "Специалист ПТО":
                    MenuItems.AddRange(new[]
                    {
                new MenuItem("Окно специалиста ПТО", typeof(PTOWindow)),
                
            });
                    break;

                case "Специалист ПСО": // Проектно-сметный отдел
                    MenuItems.AddRange(new[]
                    {
                        new MenuItem("Окно специалиста ПСО", typeof(PSOSpecialistWindow)),
                        new MenuItem("Окно проектировщика", typeof(DesignerWindow))
            });
                    break;

                case "Специалист ОКС": // Отдел капитального строительства
                    MenuItems.AddRange(new[]
                    {
                        new MenuItem("Управление проектами", typeof(OKSWindow)),
                        new MenuItem("Акты выполненных работ", typeof(OKSWindow)),
                    });
                    break;

                    //    case "Юрист": // Юридический отдел
                    //        MenuItems.AddRange(new[]
                    //        {
                    //    new MenuItem("Договоры", typeof(ContractsView)),
                    //    new MenuItem("Доп. соглашения", typeof(AdditionalAgreementsView)),
                    //    new MenuItem("Протоколы разногласий", typeof(DisputeProtocolsView)),
                    //    new MenuItem("Отчетность", typeof(ReportsView))
                    //});
                    //        break;

                    //    case "Диспетчер ЦДС": // Центральная диспетчерская служба
                    //        MenuItems.AddRange(new[]
                    //        {
                    //    new MenuItem("Согласование работ", typeof(WorkCoordinationView)),
                    //    new MenuItem("Акты пуска газа", typeof(GasStartActsView)),
                    //    new MenuItem("Отчетность", typeof(ReportsView))
                    //});
                    //        break;

                    //    case "Менеджер ОРГ": // Отдел расчетов населения за газ
                    //        MenuItems.AddRange(new[]
                    //        {
                    //    new MenuItem("Расчеты", typeof(CalculationsView)),
                    //    new MenuItem("Учет задолженностей", typeof(DebtTrackingView)),
                    //    new MenuItem("Формирование извещений", typeof(NotificationsGenerationView)),
                    //    new MenuItem("Отчетность", typeof(ReportsView))
                    //});
                    //        break;

                    //    case "Администратор": // Контроль и администрирование
                    //        MenuItems.AddRange(new[]
                    //        {
                    //    new MenuItem("Управление пользователями", typeof(UserManagementView)),
                    //    new MenuItem("Контроль сроков", typeof(DeadlineControlView)),
                    //    new MenuItem("Аудит действий", typeof(AuditLogsView)),
                    //    new MenuItem("Системные настройки", typeof(SystemSettingsView))
                    //});
                    //        break;

                    //    default: // Для неизвестных ролей
                    //        MenuItems.Add(new MenuItem("Доступ запрещен", typeof(AccessDeniedView)));
                    //        break;
            }

            MenuItemsControl.ItemsSource = MenuItems;
        }

        private void NavigateToView(object viewType)
        {
            try
            {
                if (viewType is Type type)
                {
                    CurrentView = Activator.CreateInstance(type, _userId);
                    StatusMessage = $"Загружен модуль: {((FrameworkElement)CurrentView).Tag}";
                }
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка загрузки модуля: {ex.Message}";
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void InitializeTimer()
        {
            var timer = new System.Windows.Threading.DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += (s, e) => CurrentDateTime = DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss");
            timer.Start();
        }

        private void BtnLogout_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Вы уверены, что хотите выйти?", "Подтверждение",
                                        MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                var loginWindow = new LoginWindow();
                loginWindow.Show();
                this.Close();
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public class MenuItem
    {
        public string Title { get; }
        public Type ViewType { get; }

        public MenuItem(string title, Type viewType)
        {
            Title = title;
            ViewType = viewType;
        }
    }

    public class RelayCommand : ICommand
    {
        private readonly Action<object> _execute;
        private readonly Predicate<object> _canExecute;

        public RelayCommand(Action<object> execute, Predicate<object> canExecute = null)
        {
            _execute = execute ?? throw new ArgumentNullException(nameof(execute));
            _canExecute = canExecute;
        }

        public bool CanExecute(object parameter) => _canExecute?.Invoke(parameter) ?? true;

        public void Execute(object parameter) => _execute(parameter);

        public event EventHandler CanExecuteChanged
        {
            add => CommandManager.RequerySuggested += value;
            remove => CommandManager.RequerySuggested -= value;
        }
    }
}