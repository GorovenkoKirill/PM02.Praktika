﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace PraktikaPM04
{
    public partial class PSOSpecialistWindow : UserControl
    {
        private readonly int _userId;
        private string _currentDateTime = DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss");
        private string _statusMessage = "Готово";

        public string CurrentDateTime
        {
            get => _currentDateTime;
            set
            {
                _currentDateTime = value;
                StatusMessage = $"Обновлено: {value}";
            }
        }

        public string StatusMessage
        {
            get => _statusMessage;
            set
            {
                _statusMessage = value;
                // Обновляем статус бар через привязку данных
                DataContext = this;
            }
        }


        public PSOSpecialistWindow(int userId)
        {
            _userId = userId;

            InitializeComponent();
            DataContext = this;

            LoadIncomingDocuments();
            LoadSurveyRequests();
            InitializeTimer();
        }

        private void InitializeTimer()
        {
            var timer = new System.Windows.Threading.DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += (s, e) => CurrentDateTime = DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss");
            timer.Start();
        }

        private void LoadIncomingDocuments()
        {
            try
            {
                string query = @"
            SELECT d.DocumentID, dt.TypeName AS DocumentTypeName, d.ApplicationID, 
                   d.CreationDate, aw.DeadlineDate, aw.StatusID, s.StatusName AS Status,
                   CASE 
                       WHEN DATEDIFF(day, GETDATE(), aw.DeadlineDate) <= 3 THEN 1
                       ELSE 0
                   END AS IsUrgent
            FROM Documents d
            JOIN DocumentTypes dt ON d.DocumentTypeID = dt.DocumentTypeID
            JOIN ApplicationWorkflow aw ON d.ApplicationID = aw.ApplicationID
            JOIN ApplicationStatuses s ON aw.StatusID = s.StatusID
            WHERE aw.ToDepartmentID = 3 -- ПСО
            AND aw.IsCompleted = 0
            ORDER BY aw.DeadlineDate ASC";

                DataTable documents = DatabaseHelper.ExecuteQuery(query);
                IncomingDocumentsGrid.ItemsSource = documents.DefaultView;

                // Подписка на событие загрузки строк
                IncomingDocumentsGrid.LoadingRow += (s, e) =>
                {
                    DataRowView rowView = e.Row.Item as DataRowView;
                    if (rowView != null && rowView["IsUrgent"] != DBNull.Value && (int)rowView["IsUrgent"] == 1)
                    {
                        e.Row.Background = System.Windows.Media.Brushes.LightPink;
                    }
                };
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка загрузки документов: {ex.Message}";
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LoadSurveyRequests()
        {
            try
            {
                string query = @"
                    SELECT sr.RequestID, sr.ApplicationID, sr.RequestDate, sr.Status, sr.Comments
                    FROM SurveyRequests sr
                    JOIN Applications a ON sr.ApplicationID = a.ApplicationID
                    WHERE a.StatusID IN (2, 3) -- В работе или Рассматривается
                    ORDER BY sr.RequestDate DESC";

                DataTable requests = DatabaseHelper.ExecuteQuery(query);
                SurveyRequestsGrid.ItemsSource = requests.DefaultView;
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка загрузки запросов на изыскания: {ex.Message}";
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void RefreshIncomingDocs(object sender, RoutedEventArgs e)
        {
            LoadIncomingDocuments();
            StatusMessage = "Входящие документы обновлены";
        }

        private void AcceptDocument(object sender, RoutedEventArgs e)
        {
            if (IncomingDocumentsGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите документ для принятия в работу", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DataRowView row = (DataRowView)IncomingDocumentsGrid.SelectedItem;
            int documentId = (int)row["DocumentID"];
            int applicationId = (int)row["ApplicationID"];

            try
            {
                string query = @"
                    UPDATE ApplicationWorkflow 
                    SET StatusID = 3, -- Рассматривается
                        Comments = 'Принято в работу специалистом ПСО',
                        ActionDate = GETDATE()
                    WHERE ApplicationID = @ApplicationID 
                    AND ToDepartmentID = 3 -- ПСО
                    AND IsCompleted = 0";

                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@ApplicationID", applicationId)
                };

                DatabaseHelper.ExecuteNonQuery(query, parameters);
                LoadIncomingDocuments();
                StatusMessage = $"Документ {documentId} принят в работу";
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка принятия документа: {ex.Message}";
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void RequestRevision(object sender, RoutedEventArgs e)
        {
            if (IncomingDocumentsGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите документ для запроса доработки", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DataRowView row = (DataRowView)IncomingDocumentsGrid.SelectedItem;
            int documentId = (int)row["DocumentID"];
            int applicationId = (int)row["ApplicationID"];

            // Здесь можно добавить диалог для ввода комментария
            string comment = "Требуется доработка документа";

            try
            {
                string query = @"
                    UPDATE ApplicationWorkflow 
                    SET StatusID = 5, -- Отказ
                        Comments = @Comment,
                        ActionDate = GETDATE()
                    WHERE ApplicationID = @ApplicationID 
                    AND ToDepartmentID = 3 -- ПСО
                    AND IsCompleted = 0";

                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@ApplicationID", applicationId),
                    new SqlParameter("@Comment", comment)
                };

                DatabaseHelper.ExecuteNonQuery(query, parameters);
                LoadIncomingDocuments();
                StatusMessage = $"Запрошена доработка документа {documentId}";
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка запроса доработки: {ex.Message}";
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ViewDocument_Click(object sender, RoutedEventArgs e)
        {
            if (IncomingDocumentsGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите документ для просмотра",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                DataRowView row = (DataRowView)IncomingDocumentsGrid.SelectedItem;
                int documentId = (int)row["DocumentID"];
                string documentType = row["DocumentTypeName"].ToString();

                var viewer = new DocumentViewerWindow(documentId, documentType);
                viewer.Owner = Window.GetWindow(this);
                viewer.ShowDialog();
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка открытия документа: {ex.Message}";
                MessageBox.Show($"Ошибка открытия документа:\n{ex.Message}",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CreateSurveyRequest(object sender, RoutedEventArgs e)
        {
            // Диалог создания запроса на изыскания
            var dialog = new SurveyRequestDialog();
            if (dialog.ShowDialog() == true)
            {
                try
                {
                    string query = @"
                        INSERT INTO SurveyRequests (ApplicationID, RequestDate, Status, Comments)
                        VALUES (@ApplicationID, GETDATE(), 'Новый', @Comments)";

                    SqlParameter[] parameters = new SqlParameter[]
                    {
                        new SqlParameter("@ApplicationID", dialog.ApplicationId),
                        new SqlParameter("@Comments", dialog.Comments)
                    };

                    DatabaseHelper.ExecuteNonQuery(query, parameters);
                    LoadSurveyRequests();
                    StatusMessage = "Запрос на изыскания создан";
                }
                catch (Exception ex)
                {
                    StatusMessage = $"Ошибка создания запроса: {ex.Message}";
                    MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void SendSurveyToOKS(object sender, RoutedEventArgs e)
        {
            if (SurveyRequestsGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите запрос для отправки в ОКС", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DataRowView row = (DataRowView)SurveyRequestsGrid.SelectedItem;
            int requestId = (int)row["RequestID"];
            int applicationId = (int)row["ApplicationID"];

            try
            {
                // Обновляем статус запроса
                string updateQuery = @"
                    UPDATE SurveyRequests 
                    SET Status = 'Отправлен в ОКС'
                    WHERE RequestID = @RequestID";

                SqlParameter[] updateParams = new SqlParameter[]
                {
                    new SqlParameter("@RequestID", requestId)
                };

                DatabaseHelper.ExecuteNonQuery(updateQuery, updateParams);

                // Создаем workflow для ОКС
                string workflowQuery = @"
                    INSERT INTO ApplicationWorkflow (ApplicationID, FromDepartmentID, ToDepartmentID, StatusID, 
                                                    ActionDate, Comments, ProcessingDeadline, DeadlineDate)
                    VALUES (@ApplicationID, 3, 4, 2, GETDATE(), 'Запрос на изыскания', 5, DATEADD(day, 5, GETDATE()))";

                SqlParameter[] workflowParams = new SqlParameter[]
                {
                    new SqlParameter("@ApplicationID", applicationId)
                };

                DatabaseHelper.ExecuteNonQuery(workflowQuery, workflowParams);

                LoadSurveyRequests();
                StatusMessage = $"Запрос {requestId} отправлен в ОКС";
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка отправки запроса: {ex.Message}";
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


    }
}