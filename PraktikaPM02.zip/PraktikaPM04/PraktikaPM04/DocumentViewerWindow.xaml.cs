﻿using System;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Windows;

namespace PraktikaPM04
{
    public partial class DocumentViewerWindow : Window
    {
        private readonly int _documentId;
        private string _filePath;

        public DocumentViewerWindow(int documentId, string documentType)
        {
            InitializeComponent();
            _documentId = documentId;
            LoadDocumentData(documentType);
        }

        private void LoadDocumentData(string documentType)
        {
            try
            {
                string query = @"
                    SELECT 
                        d.DocumentID,
                        d.ApplicationID,
                        d.CreationDate,
                        d.FilePath,
                        d.IsAttached,
                        CASE 
                            WHEN tc.ConditionID IS NOT NULL THEN tc.ConditionsText
                            WHEN cc.ContractID IS NOT NULL THEN 'Договор №' + cc.ContractNumber + ' от ' + CONVERT(NVARCHAR, cc.ContractDate, 104)
                            WHEN aa.AgreementID IS NOT NULL THEN 'Доп. соглашение: ' + aa.AgreementType
                            WHEN cp.ProjectID IS NOT NULL THEN 'Проект: ' + cp.ProjectName
                            WHEN gca.ActID IS NOT NULL THEN 'Акт пуска газа №' + gca.ActNumber
                            ELSE ''
                        END AS AdditionalInfo
                    FROM Documents d
                    LEFT JOIN TechnicalConditions tc ON d.DocumentID = tc.DocumentID
                    LEFT JOIN ConnectionContracts cc ON d.DocumentID = cc.DocumentID
                    LEFT JOIN AdditionalAgreements aa ON d.DocumentID = aa.DocumentID
                    LEFT JOIN ConstructionProjects cp ON d.DocumentID = cp.DocumentID
                    LEFT JOIN GasConnectionActs gca ON d.DocumentID = gca.DocumentID
                    WHERE d.DocumentID = @DocumentID";

                DataTable result = DatabaseHelper.ExecuteQuery(query,
                    new SqlParameter[] { new SqlParameter("@DocumentID", _documentId) });

                if (result.Rows.Count > 0)
                {
                    DataRow row = result.Rows[0];
                    _filePath = row["FilePath"] != DBNull.Value ? row["FilePath"].ToString() : null;

                    var viewModel = new DocumentViewModel
                    {
                        DocumentId = _documentId,
                        DocumentType = documentType,
                        ApplicationId = Convert.ToInt32(row["ApplicationID"]),
                        CreationDate = Convert.ToDateTime(row["CreationDate"]),
                        FilePath = _filePath ?? "Файл не прикреплен",
                        AdditionalInfo = row["AdditionalInfo"].ToString()
                    };

                    DataContext = viewModel;

                    // Загрузка предпросмотра, если файл существует
                    if (!string.IsNullOrEmpty(_filePath))
                    {
                        LoadDocumentPreview();
                    }
                    else
                    {
                        PreviewTab.IsEnabled = false;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных документа: {ex.Message}",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                Close();
            }
        }

        private void LoadDocumentPreview()
        {
            try
            {
                if (File.Exists(_filePath))
                {
                    string extension = Path.GetExtension(_filePath).ToLower();

                    // Поддерживаемые форматы для предпросмотра
                    if (extension == ".pdf" || extension == ".doc" ||
                        extension == ".docx" || extension == ".xls" ||
                        extension == ".xlsx")
                    {
                        DocumentBrowser.Navigate(_filePath);
                    }
                    else
                    {
                        PreviewTab.IsEnabled = false;
                    }
                }
                else
                {
                    PreviewTab.IsEnabled = false;
                }
            }
            catch
            {
                PreviewTab.IsEnabled = false;
            }
        }

        private void OpenFileButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(_filePath))
            {
                MessageBox.Show("Файл документа не прикреплен.",
                    "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            try
            {
                if (File.Exists(_filePath))
                {
                    Process.Start(new ProcessStartInfo
                    {
                        FileName = _filePath,
                        UseShellExecute = true
                    });
                }
                else
                {
                    MessageBox.Show($"Файл не найден по пути:\n{_filePath}",
                        "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при открытии файла:\n{ex.Message}",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
public class DocumentViewModel : INotifyPropertyChanged
{
    private int _documentId;
    private string _documentType;
    private int _applicationId;
    private DateTime _creationDate;
    private string _filePath;
    private string _additionalInfo;

    public int DocumentId
    {
        get => _documentId;
        set { _documentId = value; OnPropertyChanged(nameof(DocumentId)); }
    }

    public string DocumentType
    {
        get => _documentType;
        set { _documentType = value; OnPropertyChanged(nameof(DocumentType)); }
    }

    public int ApplicationId
    {
        get => _applicationId;
        set { _applicationId = value; OnPropertyChanged(nameof(ApplicationId)); }
    }

    public DateTime CreationDate
    {
        get => _creationDate;
        set { _creationDate = value; OnPropertyChanged(nameof(CreationDate)); }
    }

    public string FilePath
    {
        get => _filePath;
        set { _filePath = value; OnPropertyChanged(nameof(FilePath)); }
    }

    public string AdditionalInfo
    {
        get => _additionalInfo;
        set { _additionalInfo = value; OnPropertyChanged(nameof(AdditionalInfo)); }
    }

    public event PropertyChangedEventHandler PropertyChanged;

    protected virtual void OnPropertyChanged(string propertyName)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}