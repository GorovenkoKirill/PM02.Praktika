﻿using System.Windows;

namespace PraktikaPM04
{
    public partial class CommentDialog : Window
    {
        public string Comment { get; private set; }
        public string Message { get; set; }

        public CommentDialog(string message)
        {
            Message = message;
            InitializeComponent();
            DataContext = this;
        }

        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(CommentTextBox.Text))
            {
                MessageBox.Show("Введите комментарий", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            Comment = CommentTextBox.Text;
            DialogResult = true;
            Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}