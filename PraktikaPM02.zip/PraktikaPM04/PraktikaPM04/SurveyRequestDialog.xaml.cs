﻿using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;

namespace PraktikaPM04
{
    public partial class SurveyRequestDialog : Window
    {
        public int ApplicationId { get; private set; }
        public string Comments { get; private set; }

        public SurveyRequestDialog()
        {
            InitializeComponent();
            LoadApplications();
            ApplicationsComboBox.SelectionChanged += ApplicationsComboBox_SelectionChanged;
        }

        private void LoadApplications()
        {
            try
            {
                string query = @"
                    SELECT a.ApplicationID, c.FullName, a.ObjectName
                    FROM Applications a
                    JOIN Clients c ON a.ClientID = c.ClientID
                    WHERE a.StatusID IN (2, 3) -- В работе или Рассматривается
                    ORDER BY a.ApplicationID DESC";

                DataTable applications = DatabaseHelper.ExecuteQuery(query);
                ApplicationsComboBox.ItemsSource = applications.DefaultView;

                if (applications.Rows.Count > 0)
                {
                    ApplicationsComboBox.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки заявок: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ApplicationsComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ApplicationsComboBox.SelectedItem is DataRowView row)
            {
                ClientInfoTextBlock.Text = row["FullName"].ToString();
            }
        }

        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            if (ApplicationsComboBox.SelectedItem == null)
            {
                MessageBox.Show("Выберите заявку", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            ApplicationId = (int)ApplicationsComboBox.SelectedValue;
            Comments = CommentsTextBox.Text;
            DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}