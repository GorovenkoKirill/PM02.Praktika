﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;

namespace PraktikaPM04
{
    public partial class EstimateWindow : Window
    {
        private int _applicationId;

        public EstimateWindow(int applicationId)
        {
            InitializeComponent();
            _applicationId = applicationId;
            Loaded += EstimateWindow_Loaded;
            Title = $"Создание сметы для заявки №{applicationId}";
        }

        private void EstimateWindow_Loaded(object sender, RoutedEventArgs e)
        {
            LoadEstimateItems();
        }

        private void LoadEstimateItems()
        {
            try
            {
                string query = @"
                    SELECT 
                        ItemNumber,
                        ItemName,
                        Unit,
                        Quantity,
                        UnitPrice
                    FROM EstimateItems
                    WHERE ApplicationID = @ApplicationID
                    ORDER BY ItemNumber";

                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@ApplicationID", _applicationId)
                };

                DataTable dt = DatabaseHelper.ExecuteQuery(query, parameters);
                dgEstimateItems.ItemsSource = dt.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке позиций сметы: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnAddItem_Click(object sender, RoutedEventArgs e)
        {
            var addItemWindow = new AddEstimateItemWindow(_applicationId);
            if (addItemWindow.ShowDialog() == true)
            {
                LoadEstimateItems();
            }
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Сохранение сметы как документа
                string query = @"
                    INSERT INTO Documents (ApplicationID, DocumentTypeID, FilePath, IsAttached)
                    VALUES (@ApplicationID, 5, @FilePath, 1)";

                string filePath = $"\\\\server\\docs\\app{_applicationId}\\estimate_{DateTime.Now:yyyyMMdd}.pdf";

                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@ApplicationID", _applicationId),
                    new SqlParameter("@FilePath", filePath)
                };

                DatabaseHelper.ExecuteNonQuery(query, parameters);

                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении сметы: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}