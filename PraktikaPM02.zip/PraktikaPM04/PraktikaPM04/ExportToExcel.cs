﻿using System.Data;
using System.IO;
using Microsoft.Office.Interop.Excel;

namespace PraktikaPM04
{
    public static class ExportToExcel
    {
        public static void Export(System.Data.DataTable dataTable, string filePath)
        {
            Application excelApp = new Application();
            Workbook workbook = excelApp.Workbooks.Add();
            Worksheet worksheet = workbook.ActiveSheet;

            // Добавляем заголовки
            for (int i = 0; i < dataTable.Columns.Count; i++)
            {
                worksheet.Cells[1, i + 1] = dataTable.Columns[i].ColumnName;
            }

            // Добавляем данные
            for (int row = 0; row < dataTable.Rows.Count; row++)
            {
                for (int col = 0; col < dataTable.Columns.Count; col++)
                {
                    worksheet.Cells[row + 2, col + 1] = dataTable.Rows[row][col];
                }
            }

            // Автонастройка ширины столбцов
            worksheet.Columns.AutoFit();

            // Сохраняем файл
            if (File.Exists(filePath))
            {
                File.Delete(filePath);
            }

            workbook.SaveAs(filePath);
            workbook.Close();
            excelApp.Quit();

            // Освобождаем ресурсы
            System.Runtime.InteropServices.Marshal.ReleaseComObject(worksheet);
            System.Runtime.InteropServices.Marshal.ReleaseComObject(workbook);
            System.Runtime.InteropServices.Marshal.ReleaseComObject(excelApp);
        }
    }
}