﻿using System.Windows;

namespace PraktikaPM04
{
    public partial class RejectReasonDialog : Window
    {
        public string Reason { get; private set; }

        public RejectReasonDialog()
        {
            InitializeComponent();
        }

        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtReason.Text))
            {
                MessageBox.Show("Укажите причину отклонения", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            Reason = txtReason.Text;
            DialogResult = true;
            Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}