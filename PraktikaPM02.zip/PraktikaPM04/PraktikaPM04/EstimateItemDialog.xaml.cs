﻿using System.Windows;

namespace PraktikaPM04
{
    public partial class EstimateItemDialog : Window
    {
        public int ItemNumber { get; private set; }
        public string ItemName { get; private set; }
        public string Unit { get; private set; }
        public decimal Quantity { get; private set; }
        public decimal UnitPrice { get; private set; }

        public EstimateItemDialog()
        {
            InitializeComponent();
        }

        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            if (ValidateInput())
            {
                ItemNumber = int.Parse(txtItemNumber.Text);
                ItemName = txtItemName.Text;
                Unit = txtUnit.Text;
                Quantity = decimal.Parse(txtQuantity.Text);
                UnitPrice = decimal.Parse(txtUnitPrice.Text);

                DialogResult = true;
                Close();
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private bool ValidateInput()
        {
            if (string.IsNullOrWhiteSpace(txtItemNumber.Text) ||
                string.IsNullOrWhiteSpace(txtItemName.Text) ||
                string.IsNullOrWhiteSpace(txtUnit.Text) ||
                string.IsNullOrWhiteSpace(txtQuantity.Text) ||
                string.IsNullOrWhiteSpace(txtUnitPrice.Text))
            {
                MessageBox.Show("Заполните все поля", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (!int.TryParse(txtItemNumber.Text, out _))
            {
                MessageBox.Show("Номер позиции должен быть целым числом", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (!decimal.TryParse(txtQuantity.Text, out _) || !decimal.TryParse(txtUnitPrice.Text, out _))
            {
                MessageBox.Show("Количество и цена должны быть числовыми значениями", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            return true;
        }
    }
}