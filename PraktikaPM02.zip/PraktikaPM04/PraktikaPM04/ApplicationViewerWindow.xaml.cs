﻿using PraktikaPM04.SRZ;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;

namespace PraktikaPM04
{
    public partial class ApplicationViewerWindow : Window
    {
        private readonly int _applicationId;
        private readonly int _userId;

        public ApplicationViewerWindow(int applicationId, int userId)
        {
            InitializeComponent();
            _applicationId = applicationId;
            _userId = userId;
            LoadApplicationDetails();
            LoadDocuments();
            LoadWorkflow();
            this.Title = $"Заявка №{_applicationId}";
        }

        private void LoadApplicationDetails()
        {
            string query = @"
                SELECT 
                    a.ApplicationID, 
                    a.ObjectName, 
                    a.ConstructionCode,
                    a.ApplicationReason,
                    a.Comments,
                    a.CreationDate,
                    a.ModificationDate,
                    a.CompletionDate,
                    c.FullName AS ClientName,
                    ct.TypeName AS ClientType,
                    at.TypeName AS ApplicationType,
                    s.StatusName
                FROM Applications a
                JOIN Clients c ON a.ClientID = c.ClientID
                JOIN ClientTypes ct ON c.ClientTypeID = ct.ClientTypeID
                JOIN ApplicationTypes at ON a.ApplicationTypeID = at.ApplicationTypeID
                JOIN ApplicationStatuses s ON a.StatusID = s.StatusID
                WHERE a.ApplicationID = @ApplicationID";

            var parameters = new[] { new SqlParameter("@ApplicationID", _applicationId) };

            DataTable result = DatabaseHelper.ExecuteQuery(query, parameters);
            if (result.Rows.Count == 0)
            {
                MessageBox.Show("Заявка не найдена", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                this.Close();
                return;
            }

            DataRow row = result.Rows[0];

            lblApplicationId.Content = row["ApplicationID"].ToString();
            lblObjectName.Content = row["ObjectName"].ToString();
            lblConstructionCode.Content = row["ConstructionCode"].ToString();
            lblApplicationReason.Content = row["ApplicationReason"].ToString();
            txtComments.Text = row["Comments"].ToString();
            lblCreationDate.Content = ((DateTime)row["CreationDate"]).ToString("dd.MM.yyyy HH:mm");
            lblModificationDate.Content = ((DateTime)row["ModificationDate"]).ToString("dd.MM.yyyy HH:mm");
            lblCompletionDate.Content = row["CompletionDate"] == DBNull.Value ?
                "Не завершена" : ((DateTime)row["CompletionDate"]).ToString("dd.MM.yyyy HH:mm");
            lblClientName.Content = row["ClientName"].ToString();
            lblClientType.Content = row["ClientType"].ToString();
            lblApplicationType.Content = row["ApplicationType"].ToString();
            lblStatus.Content = row["StatusName"].ToString();
        }

        private void LoadDocuments()
        {
            string query = @"
                SELECT 
                    d.DocumentID,
                    dt.TypeName AS DocumentType,
                    d.FilePath,
                    d.IsAttached,
                    d.CreationDate
                FROM Documents d
                JOIN DocumentTypes dt ON d.DocumentTypeID = dt.DocumentTypeID
                WHERE d.ApplicationID = @ApplicationID
                ORDER BY d.CreationDate DESC";

            var parameters = new[] { new SqlParameter("@ApplicationID", _applicationId) };

            DataTable documents = DatabaseHelper.ExecuteQuery(query, parameters);
            dgDocuments.ItemsSource = documents.DefaultView;
        }

        private void LoadWorkflow()
        {
            string query = @"
                SELECT 
                    w.WorkflowID,
                    fd.DepartmentName AS FromDepartment,
                    td.DepartmentName AS ToDepartment,
                    s.StatusName,
                    w.ActionDate,
                    w.Comments,
                    w.ProcessingDeadline,
                    w.DeadlineDate,
                    CASE WHEN w.IsCompleted = 1 THEN 'Да' ELSE 'Нет' END AS IsCompleted,
                    w.CompletionDate
                FROM ApplicationWorkflow w
                LEFT JOIN Departments fd ON w.FromDepartmentID = fd.DepartmentID
                JOIN Departments td ON w.ToDepartmentID = td.DepartmentID
                JOIN ApplicationStatuses s ON w.StatusID = s.StatusID
                WHERE w.ApplicationID = @ApplicationID
                ORDER BY w.ActionDate DESC";

            var parameters = new[] { new SqlParameter("@ApplicationID", _applicationId) };

            DataTable workflow = DatabaseHelper.ExecuteQuery(query, parameters);
            dgWorkflow.ItemsSource = workflow.DefaultView;
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btnChangeStatus_Click(object sender, RoutedEventArgs e)
        {
            var statusWindow = new ChangeStatusWindow(_applicationId, _userId);
            if (statusWindow.ShowDialog() == true)
            {
                LoadApplicationDetails();
                LoadWorkflow();
            }
        }

        private void btnAddDocument_Click(object sender, RoutedEventArgs e)
        {
            var addDocWindow = new AddDocumentWindow(_applicationId, _userId);
            if (addDocWindow.ShowDialog() == true)
            {
                LoadDocuments();
            }
        }
    }
}