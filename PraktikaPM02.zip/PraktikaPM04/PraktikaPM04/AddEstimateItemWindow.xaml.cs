﻿using System;
using System.Data;
using System.Windows;
using System.Data.SqlClient;

namespace PraktikaPM04
{
    public partial class AddEstimateItemWindow : Window
    {
        private int _applicationId;

        public AddEstimateItemWindow(int applicationId)
        {
            InitializeComponent();
            _applicationId = applicationId;
            cmbUnit.SelectedIndex = 0;
        }

        private void btnOK_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtItemName.Text) ||
                string.IsNullOrWhiteSpace(txtQuantity.Text) ||
                string.IsNullOrWhiteSpace(txtUnitPrice.Text))
            {
                MessageBox.Show("Заполните все обязательные поля", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                int itemNumber = string.IsNullOrWhiteSpace(txtItemNumber.Text) ?
                    GetNextItemNumber() : Convert.ToInt32(txtItemNumber.Text);
                decimal quantity = Convert.ToDecimal(txtQuantity.Text);
                decimal unitPrice = Convert.ToDecimal(txtUnitPrice.Text);

                string query = @"
                    INSERT INTO EstimateItems (ApplicationID, ItemNumber, ItemName, Unit, Quantity, UnitPrice)
                    VALUES (@ApplicationID, @ItemNumber, @ItemName, @Unit, @Quantity, @UnitPrice)";

                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@ApplicationID", _applicationId),
                    new SqlParameter("@ItemNumber", itemNumber),
                    new SqlParameter("@ItemName", txtItemName.Text),
                    new SqlParameter("@Unit", cmbUnit.SelectedValue.ToString()),
                    new SqlParameter("@Quantity", quantity),
                    new SqlParameter("@UnitPrice", unitPrice)
                };

                DatabaseHelper.ExecuteNonQuery(query, parameters);

                DialogResult = true;
                Close();
            }
            catch (FormatException)
            {
                MessageBox.Show("Проверьте правильность ввода числовых значений", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении позиции: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private int GetNextItemNumber()
        {
            string query = "SELECT ISNULL(MAX(ItemNumber), 0) + 1 FROM EstimateItems WHERE ApplicationID = @ApplicationID";
            SqlParameter parameter = new SqlParameter("@ApplicationID", _applicationId);
            return Convert.ToInt32(DatabaseHelper.ExecuteScalar(query, new[] { parameter }));
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}