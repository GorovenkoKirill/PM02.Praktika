﻿namespace PraktikaPM04
{
    public static class UserSession
    {
        public static int UserID { get; set; }
        public static string Username { get; set; }
        public static string FullName { get; set; }
        public static string Role { get; set; }
        public static int? DepartmentID { get; set; }
    }
}