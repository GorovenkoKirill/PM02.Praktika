﻿using Microsoft.Win32;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace PraktikaPM04
{
    public partial class PTOWindow : UserControl
    {
        private readonly int _userId;
        private string _currentDateTime = DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss");
        private string _statusMessage = "Готово";

        public string CurrentDateTime
        {
            get => _currentDateTime;
            set
            {
                _currentDateTime = value;
                StatusMessage = $"Обновлено: {value}";
            }
        }

        public string StatusMessage
        {
            get => _statusMessage;
            set
            {
                _statusMessage = value;
                DataContext = this;
            }
        }

        public PTOWindow(int userId)
        {
            _userId = userId;
            InitializeComponent();
            DataContext = this;

            LoadApplications();
            LoadTechnicalConditions();
            InitializeTimer();
        }

        private void InitializeTimer()
        {
            var timer = new System.Windows.Threading.DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += (s, e) => CurrentDateTime = DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss");
            timer.Start();
        }

        private void LoadApplications()
        {
            try
            {
                string query = @"
                    SELECT 
                        a.ApplicationID, 
                        at.TypeName AS ApplicationTypeName,
                        c.FullName AS ClientName,
                        a.ObjectName,
                        a.CreationDate,
                        aw.DeadlineDate,
                        s.StatusName,
                        CASE 
                            WHEN DATEDIFF(day, GETDATE(), aw.DeadlineDate) <= 3 THEN 1
                            ELSE 0
                        END AS IsUrgent
                    FROM Applications a
                    JOIN ApplicationTypes at ON a.ApplicationTypeID = at.ApplicationTypeID
                    JOIN Clients c ON a.ClientID = c.ClientID
                    JOIN ApplicationStatuses s ON a.StatusID = s.StatusID
                    JOIN ApplicationWorkflow aw ON a.ApplicationID = aw.ApplicationID
                    WHERE aw.ToDepartmentID = 2 -- ПТО
                    AND aw.IsCompleted = 0
                    ORDER BY aw.DeadlineDate ASC";

                DataTable applications = DatabaseHelper.ExecuteQuery(query);
                ApplicationsGrid.ItemsSource = applications.DefaultView;

                ApplicationsGrid.LoadingRow += (s, e) =>
                {
                    DataRowView rowView = e.Row.Item as DataRowView;
                    if (rowView != null && rowView["IsUrgent"] != DBNull.Value && (int)rowView["IsUrgent"] == 1)
                    {
                        e.Row.Background = System.Windows.Media.Brushes.LightPink;
                    }
                };
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка загрузки заявок: {ex.Message}";
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LoadTechnicalConditions()
        {
            try
            {
                string query = @"
                    SELECT 
                        tc.ConditionID,
                        tc.ApplicationID,
                        d.CreationDate,
                        CASE 
                            WHEN tc.IsApproved = 1 THEN 'Согласовано'
                            ELSE 'На согласовании'
                        END AS Status,
                        DATEADD(day, pd.StandardDeadline, d.CreationDate) AS ApprovalDeadline,
                        CASE 
                            WHEN DATEDIFF(day, GETDATE(), DATEADD(day, pd.StandardDeadline, d.CreationDate)) <= 3 THEN 1
                            ELSE 0
                        END AS IsUrgent
                    FROM TechnicalConditions tc
                    JOIN Documents d ON tc.DocumentID = d.DocumentID
                    JOIN Applications a ON tc.ApplicationID = a.ApplicationID
                    JOIN ProcessingDeadlines pd ON a.ApplicationTypeID = pd.ApplicationTypeID 
                        AND pd.DepartmentID = 2 -- ПТО
                        AND pd.DocumentTypeID = 4 -- Технические условия
                    WHERE tc.IsApproved = 0
                    ORDER BY ApprovalDeadline ASC";

                DataTable conditions = DatabaseHelper.ExecuteQuery(query);
                TechnicalConditionsGrid.ItemsSource = conditions.DefaultView;

                TechnicalConditionsGrid.LoadingRow += (s, e) =>
                {
                    DataRowView rowView = e.Row.Item as DataRowView;
                    if (rowView != null && rowView["IsUrgent"] != DBNull.Value && (int)rowView["IsUrgent"] == 1)
                    {
                        e.Row.Background = System.Windows.Media.Brushes.LightPink;
                    }
                };
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка загрузки технических условий: {ex.Message}";
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void RefreshApplications(object sender, RoutedEventArgs e)
        {
            LoadApplications();
            StatusMessage = "Список заявок обновлен";
        }

        private void AcceptApplication(object sender, RoutedEventArgs e)
        {
            if (ApplicationsGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите заявку для принятия в работу", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DataRowView row = (DataRowView)ApplicationsGrid.SelectedItem;
            int applicationId = (int)row["ApplicationID"];

            try
            {
                string query = @"
                    UPDATE ApplicationWorkflow 
                    SET StatusID = 3, -- Рассматривается
                        Comments = 'Принято в работу специалистом ПТО',
                        ActionDate  = GETDATE()
                    WHERE ApplicationID = @ApplicationID 
                    AND ToDepartmentID = 2 -- ПТО
                    AND IsCompleted = 0";

                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@ApplicationID", applicationId)
                };

                DatabaseHelper.ExecuteNonQuery(query, parameters);

                // Обновляем статус заявки
                string updateAppQuery = "UPDATE Applications SET StatusID = 3 WHERE ApplicationID = @ApplicationID";
                DatabaseHelper.ExecuteNonQuery(updateAppQuery, parameters);

                LoadApplications();
                StatusMessage = $"Заявка {applicationId} принята в работу";
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка принятия заявки: {ex.Message}";
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void RejectApplication(object sender, RoutedEventArgs e)
        {
            if (ApplicationsGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите заявку для отклонения", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DataRowView row = (DataRowView)ApplicationsGrid.SelectedItem;
            int applicationId = (int)row["ApplicationID"];

            // Здесь можно добавить диалог для ввода причины отказа
            string comment = "Отклонено специалистом ПТО";

            try
            {
                string query = @"
                    UPDATE ApplicationWorkflow 
                    SET StatusID = 5, -- Отказ
                        Comments = @Comment,
                        ActionDate  = GETDATE(),
                        IsCompleted = 1,
                        CompletionDate = GETDATE()
                    WHERE ApplicationID = @ApplicationID 
                    AND ToDepartmentID = 2 -- ПТО
                    AND IsCompleted = 0";

                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@ApplicationID", applicationId),
                    new SqlParameter("@Comment", comment)
                };

                DatabaseHelper.ExecuteNonQuery(query, parameters);

                // Обновляем статус заявки
                string updateAppQuery = "UPDATE Applications SET StatusID = 5 WHERE ApplicationID = @ApplicationID";
                DatabaseHelper.ExecuteNonQuery(updateAppQuery, new SqlParameter[] { new SqlParameter("@ApplicationID", applicationId) });

                // Создаем уведомление
                string notificationQuery = @"
                    INSERT INTO Notifications (ApplicationID, NotificationType, NotificationText, 
                                              NotificationDate, IsSent, SentDate, Recipient, ContactMethod)
                    SELECT 
                        @ApplicationID,
                        'Rejection',
                        'Ваша заявка №' + CAST(@ApplicationID AS NVARCHAR) + ' отклонена. Причина: ' + @Comment,
                        GETDATE(),
                        1,
                        GETDATE(),
                        c.FullName,
                        c.PreferredContactMethod
                    FROM Applications a
                    JOIN Clients c ON a.ClientID = c.ClientID
                    WHERE a.ApplicationID = @ApplicationID";

                DatabaseHelper.ExecuteNonQuery(notificationQuery, parameters);

                LoadApplications();
                StatusMessage = $"Заявка {applicationId} отклонена";
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка отклонения заявки: {ex.Message}";
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void GenerateTechnicalConditions(object sender, RoutedEventArgs e)
        {
            if (ApplicationsGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите заявку для формирования ТУ", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DataRowView row = (DataRowView)ApplicationsGrid.SelectedItem;
            int applicationId = (int)row["ApplicationID"];

            // Диалог создания технических условий
            var dialog = new TechnicalConditionsDialog();
            if (dialog.ShowDialog() == true)
            {
                try
                {
                    // Сначала создаем документ
                    string docQuery = @"
                        INSERT INTO Documents (ApplicationID, DocumentTypeID, FilePath, IsAttached)
                        VALUES (@ApplicationID, 4, @FilePath, 0);
                        SELECT SCOPE_IDENTITY();";

                    SqlParameter[] docParams = new SqlParameter[]
                    {
                        new SqlParameter("@ApplicationID", applicationId),
                        new SqlParameter("@FilePath", dialog.FilePath)
                    };

                    int documentId = Convert.ToInt32(DatabaseHelper.ExecuteScalar(docQuery, docParams));

                    // Затем создаем технические условия
                    string tcQuery = @"
                        INSERT INTO TechnicalConditions (ApplicationID, DocumentID, ConditionsText, IsApproved)
                        VALUES (@ApplicationID, @DocumentID, @ConditionsText, 0)";

                    SqlParameter[] tcParams = new SqlParameter[]
                    {
                        new SqlParameter("@ApplicationID", applicationId),
                        new SqlParameter("@DocumentID", documentId),
                        new SqlParameter("@ConditionsText", dialog.ConditionsText)
                    };

                    DatabaseHelper.ExecuteNonQuery(tcQuery, tcParams);

                    // Обновляем workflow
                    string workflowQuery = @"
                        UPDATE ApplicationWorkflow 
                        SET IsCompleted = 1, 
                            CompletionDate = GETDATE(),
                            Comments = 'Сформированы технические условия'
                        WHERE ApplicationID = @ApplicationID 
                        AND ToDepartmentID = 2 -- ПТО
                        AND IsCompleted = 0;
                        
                        -- Создаем новую запись workflow для согласования ТУ
                        INSERT INTO ApplicationWorkflow (ApplicationID, FromDepartmentID, ToDepartmentID, StatusID, 
                                                        ActionDate, Comments, ProcessingDeadline, DeadlineDate)
                        VALUES (@ApplicationID, 2, 2, 3, GETDATE(), 'Технические условия на согласовании', 
                                5, DATEADD(day, 5, GETDATE()))";

                    DatabaseHelper.ExecuteNonQuery(workflowQuery, new SqlParameter[] { new SqlParameter("@ApplicationID", applicationId) });

                    LoadApplications();
                    LoadTechnicalConditions();
                    StatusMessage = $"Технические условия для заявки {applicationId} сформированы";
                }
                catch (Exception ex)
                {
                    StatusMessage = $"Ошибка формирования ТУ: {ex.Message}";
                    MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void RefreshTechnicalConditions(object sender, RoutedEventArgs e)
        {
            LoadTechnicalConditions();
            StatusMessage = "Список технических условий обновлен";
        }

        private void ApproveTechnicalConditions(object sender, RoutedEventArgs e)
        {
            if (TechnicalConditionsGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите технические условия для согласования", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DataRowView row = (DataRowView)TechnicalConditionsGrid.SelectedItem;
            int conditionId = (int)row["ConditionID"];
            int applicationId = (int)row["ApplicationID"];

            try
            {
                string query = @"
                    UPDATE TechnicalConditions 
                    SET IsApproved = 1,
                        ApprovalDate = GETDATE(),
                        ApprovedBy = @ApprovedBy
                    WHERE ConditionID = @ConditionID;
                    
                    -- Обновляем workflow
                    UPDATE ApplicationWorkflow 
                    SET IsCompleted = 1, 
                        CompletionDate = GETDATE(),
                        Comments = 'Технические условия согласованы'
                    WHERE ApplicationID = @ApplicationID 
                    AND ToDepartmentID = 2 -- ПТО
                    AND IsCompleted = 0;
                    
                    -- Создаем новую запись workflow для передачи в следующий отдел
                    -- В зависимости от типа заявки определяем следующий отдел
                    INSERT INTO ApplicationWorkflow (ApplicationID, FromDepartmentID, ToDepartmentID, StatusID, 
                                                    ActionDate, Comments, ProcessingDeadline, DeadlineDate)
                    SELECT 
                        @ApplicationID, 
                        2, 
                        CASE 
                            WHEN a.ApplicationTypeID = 1 THEN 3 -- ПСО для заявок на подключение
                            WHEN a.ApplicationTypeID = 2 THEN 5 -- ЮО для запросов на ТУ
                            ELSE 1 -- СРЗ для остальных
                        END,
                        3, -- Рассматривается
                        GETDATE(), 
                        'Технические условия согласованы', 
                        CASE 
                            WHEN a.ApplicationTypeID = 1 THEN 14 -- ПСО
                            WHEN a.ApplicationTypeID = 2 THEN 3  -- ЮО
                            ELSE 1 -- СРЗ
                        END,
                        DATEADD(day, 
                            CASE 
                                WHEN a.ApplicationTypeID = 1 THEN 14 -- ПСО
                                WHEN a.ApplicationTypeID = 2 THEN 3  -- ЮО
                                ELSE 1 -- СРЗ
                            END, GETDATE())
                    FROM Applications a
                    WHERE a.ApplicationID = @ApplicationID";

                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@ConditionID", conditionId),
                    new SqlParameter("@ApplicationID", applicationId),
                    new SqlParameter("@ApprovedBy", UserSession.FullName)
                };

                DatabaseHelper.ExecuteNonQuery(query, parameters);

                // Обновляем статус заявки, если это запрос на ТУ
                string updateAppQuery = @"
                    UPDATE Applications 
                    SET StatusID = CASE 
                                      WHEN ApplicationTypeID = 2 THEN 4 -- Одобрена для запросов на ТУ
                                      ELSE StatusID 
                                   END
                    WHERE ApplicationID = @ApplicationID";

                DatabaseHelper.ExecuteNonQuery(updateAppQuery, new SqlParameter[] { new SqlParameter("@ApplicationID", applicationId) });

                LoadTechnicalConditions();
                StatusMessage = $"Технические условия {conditionId} согласованы";
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка согласования ТУ: {ex.Message}";
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ReturnTechnicalConditions(object sender, RoutedEventArgs e)
        {
            if (TechnicalConditionsGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите технические условия для возврата на доработку", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DataRowView row = (DataRowView)TechnicalConditionsGrid.SelectedItem;
            int conditionId = (int)row["ConditionID"];
            int applicationId = (int)row["ApplicationID"];

            // Диалог для ввода комментария
            var dialog = new CommentDialog("Укажите причину возврата на доработку:");
            if (dialog.ShowDialog() == true)
            {
                try
                {
                    string query = @"
                        -- Обновляем workflow
                        UPDATE ApplicationWorkflow 
                        SET IsCompleted = 1, 
                            CompletionDate = GETDATE(),
                            Comments = 'Технические условия возвращены на доработку: ' + @Comment
                        WHERE ApplicationID = @ApplicationID 
                        AND ToDepartmentID = 2 -- ПТО
                        AND IsCompleted = 0;
                        
                        -- Создаем новую запись workflow для доработки
                        INSERT INTO ApplicationWorkflow (ApplicationID, FromDepartmentID, ToDepartmentID, StatusID, 
                                                        ActionDate, Comments, ProcessingDeadline, DeadlineDate)
                        VALUES (@ApplicationID, 2, 2, 5, GETDATE(), 'Требуется доработка технических условий: ' + @Comment, 
                                5, DATEADD(day, 5, GETDATE()))";

                    SqlParameter[] parameters = new SqlParameter[]
                    {
                        new SqlParameter("@ApplicationID", applicationId),
                        new SqlParameter("@Comment", dialog.Comment)
                    };

                    DatabaseHelper.ExecuteNonQuery(query, parameters);

                    LoadTechnicalConditions();
                    StatusMessage = $"Технические условия {conditionId} возвращены на доработку";
                }
                catch (Exception ex)
                {
                    StatusMessage = $"Ошибка возврата ТУ: {ex.Message}";
                    MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void ViewApplication_Click(object sender, RoutedEventArgs e)
        {
            if (ApplicationsGrid.SelectedItem == null) return;

            DataRowView row = (DataRowView)ApplicationsGrid.SelectedItem;
            int applicationId = (int)row["ApplicationID"];

            // Здесь можно реализовать просмотр заявки
            var viewer = new ApplicationViewerWindow(applicationId, _userId);
            viewer.ShowDialog();
        }

        private void ViewTechnicalConditions_Click(object sender, RoutedEventArgs e)
        {
            if (TechnicalConditionsGrid.SelectedItem == null) return;

            DataRowView row = (DataRowView)TechnicalConditionsGrid.SelectedItem;
            int conditionId = (int)row["ConditionID"];

            // Здесь можно реализовать просмотр технических условий
            var viewer = new DocumentViewerWindow(conditionId, "TechnicalConditions");
            viewer.ShowDialog();
        }
    }
}