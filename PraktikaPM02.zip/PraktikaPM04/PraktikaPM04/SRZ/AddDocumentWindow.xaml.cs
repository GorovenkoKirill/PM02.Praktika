﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml;
using Path = System.IO.Path;

namespace PraktikaPM04.SRZ
{
    /// <summary>
    /// Логика взаимодействия для AddDocumentWindow.xaml
    /// </summary>
    public partial class AddDocumentWindow : Window
    {
        private readonly int _applicationId;
        private readonly int _userId;
        private string _filePath;

        public AddDocumentWindow(int applicationId, int userId)
        {
            InitializeComponent();
            _applicationId = applicationId;
            _userId = userId;
            LoadDocumentTypes();
            this.Title = $"Добавление документа к заявке №{_applicationId}";
        }

        private void LoadDocumentTypes()
        {
            string query = "SELECT DocumentTypeID, TypeName FROM DocumentTypes";
            DataTable docTypes = DatabaseHelper.ExecuteQuery(query);
            cmbDocumentType.ItemsSource = docTypes.DefaultView;
            cmbDocumentType.DisplayMemberPath = "TypeName";
            cmbDocumentType.SelectedValuePath = "DocumentTypeID";
        }

        private void btnBrowse_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == true)
            {
                _filePath = openFileDialog.FileName;
                txtFilePath.Text = _filePath;
            }
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            if (cmbDocumentType.SelectedValue == null)
            {
                MessageBox.Show("Выберите тип документа", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(_filePath))
            {
                MessageBox.Show("Выберите файл для загрузки", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                string targetDirectory = $"\\\\server\\docs\\app{_applicationId}";
                if (!Directory.Exists(targetDirectory))
                {
                    Directory.CreateDirectory(targetDirectory);
                }

                string fileName = Path.GetFileName(_filePath);
                string targetPath = Path.Combine(targetDirectory, fileName);

                if (File.Exists(targetPath))
                {
                    fileName = $"{Path.GetFileNameWithoutExtension(fileName)}_{DateTime.Now:yyyyMMddHHmmss}{Path.GetExtension(fileName)}";
                    targetPath = Path.Combine(targetDirectory, fileName);
                }

                File.Copy(_filePath, targetPath);

                string query = @"
                    INSERT INTO Documents (
                        ApplicationID, DocumentTypeID, FilePath, IsAttached
                    ) VALUES (
                        @ApplicationID, @DocumentTypeID, @FilePath, @IsAttached
                    )";

                var parameters = new[]
                {
                    new SqlParameter("@ApplicationID", _applicationId),
                    new SqlParameter("@DocumentTypeID", cmbDocumentType.SelectedValue),
                    new SqlParameter("@FilePath", targetPath),
                    new SqlParameter("@IsAttached", chkIsAttached.IsChecked ?? false)
                };

                DatabaseHelper.ExecuteNonQuery(query, parameters);

                MessageBox.Show("Документ успешно добавлен", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                this.DialogResult = true;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении документа: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }
    }
}