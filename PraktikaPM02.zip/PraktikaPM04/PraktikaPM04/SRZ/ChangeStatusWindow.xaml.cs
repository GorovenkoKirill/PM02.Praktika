﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace PraktikaPM04.SRZ
{
    /// <summary>
    /// Логика взаимодействия для ChangeStatusWindow.xaml
    /// </summary>
    public partial class ChangeStatusWindow : Window
    {
        private readonly int _applicationId;
        private readonly int _userId;

        public ChangeStatusWindow(int applicationId, int userId)
        {
            InitializeComponent();
            _applicationId = applicationId;
            _userId = userId;
            LoadStatuses();
            LoadDepartments();
            this.Title = $"Изменение статуса заявки №{_applicationId}";
        }

        private void LoadStatuses()
        {
            string query = "SELECT StatusID, StatusName FROM ApplicationStatuses";
            DataTable statuses = DatabaseHelper.ExecuteQuery(query);
            cmbStatus.ItemsSource = statuses.DefaultView;
            cmbStatus.DisplayMemberPath = "StatusName";
            cmbStatus.SelectedValuePath = "StatusID";
        }

        private void LoadDepartments()
        {
            string query = "SELECT DepartmentID, DepartmentName FROM Departments";
            DataTable departments = DatabaseHelper.ExecuteQuery(query);
            cmbToDepartment.ItemsSource = departments.DefaultView;
            cmbToDepartment.DisplayMemberPath = "DepartmentName";
            cmbToDepartment.SelectedValuePath = "DepartmentID";
        }

        // Метод валидации ввода чисел
        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            if (cmbStatus.SelectedValue == null || cmbToDepartment.SelectedValue == null)
            {
                MessageBox.Show("Выберите статус и отдел назначения", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Проверка ввода дней обработки
            if (!int.TryParse(txtProcessingDays.Text, out int processingDays) || processingDays < 1)
            {
                MessageBox.Show("Введите корректное количество дней обработки (не менее 1)", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                int statusId = (int)cmbStatus.SelectedValue;
                int toDepartmentId = (int)cmbToDepartment.SelectedValue;
                int? fromDepartmentId = GetCurrentDepartmentId();

                string query = @"
                    INSERT INTO ApplicationWorkflow (
                        ApplicationID, FromDepartmentID, ToDepartmentID, StatusID, 
                        ActionDate, Comments, ProcessingDeadline, DeadlineDate
                    ) VALUES (
                        @ApplicationID, @FromDepartmentID, @ToDepartmentID, @StatusID, 
                        GETDATE(), @Comments, @ProcessingDeadline, DATEADD(day, @ProcessingDeadline, GETDATE())
                    );
                    
                    UPDATE Applications 
                    SET StatusID = @StatusID, ModificationDate = GETDATE()
                    WHERE ApplicationID = @ApplicationID;";

                var parameters = new[]
                {
                    new SqlParameter("@ApplicationID", _applicationId),
                    new SqlParameter("@FromDepartmentID", fromDepartmentId ?? (object)DBNull.Value),
                    new SqlParameter("@ToDepartmentID", toDepartmentId),
                    new SqlParameter("@StatusID", statusId),
                    new SqlParameter("@Comments", txtComments.Text ?? (object)DBNull.Value),
                    new SqlParameter("@ProcessingDeadline", processingDays)
                };

                DatabaseHelper.ExecuteNonQuery(query, parameters);

                MessageBox.Show("Статус заявки успешно изменен", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                this.DialogResult = true;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при изменении статуса: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private int? GetCurrentDepartmentId()
        {
            string query = @"
                SELECT TOP 1 ToDepartmentID 
                FROM ApplicationWorkflow 
                WHERE ApplicationID = @ApplicationID 
                ORDER BY ActionDate DESC";

            var parameters = new[] { new SqlParameter("@ApplicationID", _applicationId) };

            object result = DatabaseHelper.ExecuteScalar(query, parameters);
            return result != null ? Convert.ToInt32(result) : (int?)null;
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }
    }
}