﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PraktikaPM04.SRZ
{
    /// <summary>
    /// Логика взаимодействия для ViewApplicationsView.xaml
    /// </summary>
    public partial class ViewApplicationsView : UserControl
    {
        private readonly int _userId;

        public ViewApplicationsView(int userId)
        {
            InitializeComponent();
            _userId = userId;
            LoadStatuses();
            LoadApplications();
            this.Tag = "Просмотр заявок";
        }

        private void LoadStatuses()
        {
            string query = "SELECT StatusID, StatusName FROM ApplicationStatuses";
            DataTable statuses = DatabaseHelper.ExecuteQuery(query);
            cmbStatusFilter.ItemsSource = statuses.DefaultView;
            cmbStatusFilter.DisplayMemberPath = "StatusName";
            cmbStatusFilter.SelectedValuePath = "StatusID";
            cmbStatusFilter.SelectedIndex = -1;
        }

        private void LoadApplications()
        {
            string query = @"
                SELECT 
                    a.ApplicationID, 
                    a.ObjectName, 
                    c.FullName AS ClientName, 
                    at.TypeName AS ApplicationType, 
                    s.StatusName,
                    a.CreationDate,
                    a.ModificationDate
                FROM Applications a
                JOIN Clients c ON a.ClientID = c.ClientID
                JOIN ApplicationTypes at ON a.ApplicationTypeID = at.ApplicationTypeID
                JOIN ApplicationStatuses s ON a.StatusID = s.StatusID
                WHERE 1=1";

            if (cmbStatusFilter.SelectedValue != null)
            {
                query += " AND a.StatusID = @StatusID";
            }

            if (!string.IsNullOrWhiteSpace(txtSearch.Text))
            {
                query += " AND (a.ObjectName LIKE @Search OR c.FullName LIKE @Search)";
            }

            query += " ORDER BY a.ModificationDate DESC";

            var parameters = new System.Collections.Generic.List<SqlParameter>();

            if (cmbStatusFilter.SelectedValue != null)
            {
                parameters.Add(new SqlParameter("@StatusID", cmbStatusFilter.SelectedValue));
            }

            if (!string.IsNullOrWhiteSpace(txtSearch.Text))
            {
                parameters.Add(new SqlParameter("@Search", $"%{txtSearch.Text}%"));
            }

            DataTable applications = DatabaseHelper.ExecuteQuery(query, parameters.ToArray());
            dgApplications.ItemsSource = applications.DefaultView;
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            LoadApplications();
        }

        private void btnClearFilters_Click(object sender, RoutedEventArgs e)
        {
            cmbStatusFilter.SelectedIndex = -1;
            txtSearch.Clear();
            LoadApplications();
        }

        private void dgApplications_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (dgApplications.SelectedItem == null) return;

            DataRowView row = (DataRowView)dgApplications.SelectedItem;
            int applicationId = (int)row["ApplicationID"];

            var detailsWindow = new ApplicationDetailsWindow(applicationId, _userId);
            detailsWindow.ShowDialog();

            // Обновляем список после закрытия окна деталей
            LoadApplications();
        }

        private void btnExport_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                DataView dataView = (DataView)dgApplications.ItemsSource;
                if (dataView == null || dataView.Count == 0)
                {
                    MessageBox.Show("Нет данных для экспорта", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                Microsoft.Win32.SaveFileDialog saveFileDialog = new Microsoft.Win32.SaveFileDialog
                {
                    Filter = "Excel файл (*.xlsx)|*.xlsx",
                    FileName = $"Заявки_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx"
                };

                if (saveFileDialog.ShowDialog() == true)
                {
                    ExportToExcel.Export(dataView.ToTable(), saveFileDialog.FileName);
                    MessageBox.Show("Экспорт завершен успешно", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при экспорте: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}