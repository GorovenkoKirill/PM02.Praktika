﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace PraktikaPM04.SRZ
{
    public partial class NotificationsView : UserControl
    {
        private readonly int _userId;

        public NotificationsView(int userId)
        {
            InitializeComponent();
            _userId = userId;
            LoadNotifications();
            this.Tag = "Уведомления";
        }

        private void LoadNotifications()
        {
            string query = @"
                SELECT 
                    n.NotificationID,
                    n.NotificationType,
                    n.NotificationText,
                    n.NotificationDate,
                    CASE WHEN n.IsSent = 1 THEN 'Да' ELSE 'Нет' END AS IsSent,
                    n.SentDate,
                    n.Recipient,
                    n.ContactMethod,
                    a.ObjectName,
                    c.FullName AS ClientName
                FROM Notifications n
                JOIN Applications a ON n.ApplicationID = a.ApplicationID
                JOIN Clients c ON a.ClientID = c.ClientID
                WHERE a.ApplicationID IN (
                    SELECT ApplicationID FROM Applications 
                    WHERE StatusID IN (1, 2, 3) -- На регистрации, В работе, Рассматривается
                )
                ORDER BY n.NotificationDate DESC";

            DataTable notifications = DatabaseHelper.ExecuteQuery(query);
            dgNotifications.ItemsSource = notifications.DefaultView;
        }

        private void btnSendNotification_Click(object sender, RoutedEventArgs e)
        {
            if (dgNotifications.SelectedItem == null) return;

            DataRowView row = (DataRowView)dgNotifications.SelectedItem;
            int notificationId = (int)row["NotificationID"];

            try
            {
                string query = @"
                    UPDATE Notifications 
                    SET IsSent = 1, 
                        SentDate = GETDATE()
                    WHERE NotificationID = @NotificationID";

                var parameters = new[] { new SqlParameter("@NotificationID", notificationId) };

                DatabaseHelper.ExecuteNonQuery(query, parameters);

                MessageBox.Show("Уведомление помечено как отправленное", "Успех",
                    MessageBoxButton.OK, MessageBoxImage.Information);

                LoadNotifications();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при обновлении уведомления: {ex.Message}",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnCreateNotification_Click(object sender, RoutedEventArgs e)
        {
            var createWindow = new CreateNotificationWindow(_userId);
            if (createWindow.ShowDialog() == true)
            {
                LoadNotifications();
            }
        }

        private void btnRefresh_Click(object sender, RoutedEventArgs e)
        {
            LoadNotifications();
        }
    }
}