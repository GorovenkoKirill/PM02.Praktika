﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace PraktikaPM04.SRZ
{
    public partial class CreateNotificationWindow : Window
    {
        private readonly int _userId;

        public CreateNotificationWindow(int userId)
        {
            InitializeComponent();
            _userId = userId;
            LoadApplications();
            LoadNotificationTypes();
            this.Title = "Создание уведомления";
        }

        private void LoadApplications()
        {
            string query = @"
                SELECT 
                    a.ApplicationID,
                    a.ObjectName,
                    c.FullName AS ClientName
                FROM Applications a
                JOIN Clients c ON a.ClientID = c.ClientID
                WHERE a.StatusID IN (1, 2, 3) -- На регистрации, В работе, Рассматривается
                ORDER BY a.ModificationDate DESC";

            DataTable applications = DatabaseHelper.ExecuteQuery(query);
            cmbApplication.ItemsSource = applications.DefaultView;
            cmbApplication.DisplayMemberPath = "ObjectName";
            cmbApplication.SelectedValuePath = "ApplicationID";
        }

        private void LoadNotificationTypes()
        {
            cmbNotificationType.Items.Add("StatusChange");
            cmbNotificationType.Items.Add("Completion");
            cmbNotificationType.Items.Add("Rejection");
            cmbNotificationType.Items.Add("Payment");
            cmbNotificationType.Items.Add("Reminder");
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            if (cmbApplication.SelectedValue == null || string.IsNullOrWhiteSpace(cmbNotificationType.Text))
            {
                MessageBox.Show("Выберите заявку и тип уведомления", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                int applicationId = (int)cmbApplication.SelectedValue;
                DataRowView selectedApp = (DataRowView)cmbApplication.SelectedItem;
                string clientName = selectedApp["ClientName"].ToString();

                string query = @"
                    INSERT INTO Notifications (
                        ApplicationID, NotificationType, NotificationText, 
                        NotificationDate, IsSent, Recipient, ContactMethod
                    ) VALUES (
                        @ApplicationID, @NotificationType, @NotificationText, 
                        GETDATE(), 0, @Recipient, @ContactMethod
                    )";

                var parameters = new[]
                {
                    new SqlParameter("@ApplicationID", applicationId),
                    new SqlParameter("@NotificationType", cmbNotificationType.Text),
                    new SqlParameter("@NotificationText", txtNotificationText.Text),
                    new SqlParameter("@Recipient", clientName),
                    new SqlParameter("@ContactMethod", cmbContactMethod.Text)
                };

                DatabaseHelper.ExecuteNonQuery(query, parameters);

                MessageBox.Show("Уведомление успешно создано", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                this.DialogResult = true;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при создании уведомления: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }

        private void cmbApplication_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cmbApplication.SelectedItem != null)
            {
                DataRowView selectedApp = (DataRowView)cmbApplication.SelectedItem;
                txtRecipient.Text = selectedApp["ClientName"].ToString();
            }
        }
    }
}