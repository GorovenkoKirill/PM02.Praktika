﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PraktikaPM04.SRZ
{
    /// <summary>
    /// Логика взаимодействия для RegisterApplicationView.xaml
    /// </summary>
    public partial class RegisterApplicationView : UserControl
    {
        private readonly int _userId;

        public RegisterApplicationView(int userId)
        {
            InitializeComponent();
            _userId = userId;
            LoadClientTypes();
            LoadApplicationTypes();
            SetDefaultDates();
            this.Tag = "Регистрация заявки";
        }

        private void LoadClientTypes()
        {
            string query = "SELECT ClientTypeID, TypeName FROM ClientTypes";
            DataTable clientTypes = DatabaseHelper.ExecuteQuery(query);
            cmbClientType.ItemsSource = clientTypes.DefaultView;
            cmbClientType.DisplayMemberPath = "TypeName";
            cmbClientType.SelectedValuePath = "ClientTypeID";
        }

        private void LoadApplicationTypes()
        {
            string query = "SELECT ApplicationTypeID, TypeName FROM ApplicationTypes";
            DataTable appTypes = DatabaseHelper.ExecuteQuery(query);
            cmbApplicationType.ItemsSource = appTypes.DefaultView;
            cmbApplicationType.DisplayMemberPath = "TypeName";
            cmbApplicationType.SelectedValuePath = "ApplicationTypeID";
        }

        private void SetDefaultDates()
        {
            dpCreationDate.SelectedDate = DateTime.Now;
            dpModificationDate.SelectedDate = DateTime.Now;
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            if (!ValidateInput()) return;

            try
            {
                int clientId = SaveClient();
                int applicationId = SaveApplication(clientId);

                MessageBox.Show($"Заявка успешно зарегистрирована. Номер заявки: {applicationId}",
                    "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                ClearForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении заявки: {ex.Message}",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private bool ValidateInput()
        {
            if (cmbClientType.SelectedValue == null)
            {
                MessageBox.Show("Выберите тип клиента", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            if (cmbApplicationType.SelectedValue == null)
            {
                MessageBox.Show("Выберите тип заявки", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtObjectName.Text))
            {
                MessageBox.Show("Введите наименование объекта", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            return true;
        }

        private int SaveClient()
        {
            int clientTypeId = (int)cmbClientType.SelectedValue;

            string query = @"INSERT INTO Clients (
                ClientTypeID, FullName, INN, OGRN, PassportSeries, PassportNumber, 
                PassportIssueDate, BirthDate, RegistrationAddress, Phone, Email, 
                PostalAddress, BankDetails, RepresentativeName, PreferredContactMethod
            ) VALUES (
                @ClientTypeID, @FullName, @INN, @OGRN, @PassportSeries, @PassportNumber, 
                @PassportIssueDate, @BirthDate, @RegistrationAddress, @Phone, @Email, 
                @PostalAddress, @BankDetails, @RepresentativeName, @PreferredContactMethod
            ); SELECT SCOPE_IDENTITY();";

            var parameters = new[]
            {
                new SqlParameter("@ClientTypeID", clientTypeId),
                new SqlParameter("@FullName", txtFullName.Text ?? (object)DBNull.Value),
                new SqlParameter("@INN", txtINN.Text ?? (object)DBNull.Value),
                new SqlParameter("@OGRN", txtOGRN.Text ?? (object)DBNull.Value),
                new SqlParameter("@PassportSeries", txtPassportSeries.Text ?? (object)DBNull.Value),
                new SqlParameter("@PassportNumber", txtPassportNumber.Text ?? (object)DBNull.Value),
                new SqlParameter("@PassportIssueDate", dpPassportIssueDate.SelectedDate ?? (object)DBNull.Value),
                new SqlParameter("@BirthDate", dpBirthDate.SelectedDate ?? (object)DBNull.Value),
                new SqlParameter("@RegistrationAddress", txtRegistrationAddress.Text ?? (object)DBNull.Value),
                new SqlParameter("@Phone", txtPhone.Text ?? (object)DBNull.Value),
                new SqlParameter("@Email", txtEmail.Text ?? (object)DBNull.Value),
                new SqlParameter("@PostalAddress", txtPostalAddress.Text ?? (object)DBNull.Value),
                new SqlParameter("@BankDetails", txtBankDetails.Text ?? (object)DBNull.Value),
                new SqlParameter("@RepresentativeName", txtRepresentativeName.Text ?? (object)DBNull.Value),
                new SqlParameter("@PreferredContactMethod", cmbContactMethod.Text ?? (object)DBNull.Value)
            };

            return Convert.ToInt32(DatabaseHelper.ExecuteScalar(query, parameters));
        }

        private int SaveApplication(int clientId)
        {
            int applicationTypeId = (int)cmbApplicationType.SelectedValue;
            int statusId = 1; // Статус "На регистрации"

            string query = @"INSERT INTO Applications (
                ClientID, ApplicationTypeID, StatusID, ObjectName, ConstructionCode, 
                ApplicationReason, Comments, CreationDate, ModificationDate
            ) VALUES (
                @ClientID, @ApplicationTypeID, @StatusID, @ObjectName, @ConstructionCode, 
                @ApplicationReason, @Comments, @CreationDate, @ModificationDate
            ); SELECT SCOPE_IDENTITY();";

            var parameters = new[]
            {
                new SqlParameter("@ClientID", clientId),
                new SqlParameter("@ApplicationTypeID", applicationTypeId),
                new SqlParameter("@StatusID", statusId),
                new SqlParameter("@ObjectName", txtObjectName.Text),
                new SqlParameter("@ConstructionCode", txtConstructionCode.Text ?? (object)DBNull.Value),
                new SqlParameter("@ApplicationReason", txtApplicationReason.Text ?? (object)DBNull.Value),
                new SqlParameter("@Comments", txtComments.Text ?? (object)DBNull.Value),
                new SqlParameter("@CreationDate", dpCreationDate.SelectedDate ?? DateTime.Now),
                new SqlParameter("@ModificationDate", dpModificationDate.SelectedDate ?? DateTime.Now)
            };

            int applicationId = Convert.ToInt32(DatabaseHelper.ExecuteScalar(query, parameters));

            // Запись в журнал workflow
            SaveWorkflowRecord(applicationId, statusId);

            return applicationId;
        }

        private void SaveWorkflowRecord(int applicationId, int statusId)
        {
            string query = @"INSERT INTO ApplicationWorkflow (
                ApplicationID, ToDepartmentID, StatusID, ActionDate, Comments, 
                ProcessingDeadline, DeadlineDate, IsCompleted, CompletionDate
            ) VALUES (
                @ApplicationID, 1, @StatusID, GETDATE(), 'Заявка зарегистрирована оператором', 
                1, DATEADD(day, 1, GETDATE()), 1, GETDATE()
            )";

            var parameters = new[]
            {
                new SqlParameter("@ApplicationID", applicationId),
                new SqlParameter("@StatusID", statusId)
            };

            DatabaseHelper.ExecuteNonQuery(query, parameters);
        }

        private void ClearForm()
        {
            // Очистка полей клиента
            txtFullName.Clear();
            txtINN.Clear();
            txtOGRN.Clear();
            txtPassportSeries.Clear();
            txtPassportNumber.Clear();
            dpPassportIssueDate.SelectedDate = null;
            dpBirthDate.SelectedDate = null;
            txtRegistrationAddress.Clear();
            txtPhone.Clear();
            txtEmail.Clear();
            txtPostalAddress.Clear();
            txtBankDetails.Clear();
            txtRepresentativeName.Clear();
            cmbContactMethod.SelectedIndex = -1;

            // Очистка полей заявки
            cmbApplicationType.SelectedIndex = -1;
            txtObjectName.Clear();
            txtConstructionCode.Clear();
            txtApplicationReason.Clear();
            txtComments.Clear();
            dpCreationDate.SelectedDate = DateTime.Now;
            dpModificationDate.SelectedDate = DateTime.Now;
        }

        private void cmbClientType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cmbClientType.SelectedValue == null) return;

            int clientTypeId = (int)cmbClientType.SelectedValue;

            // Показываем/скрываем поля в зависимости от типа клиента
            // 1 - Физическое лицо, 2 - Юридическое лицо, 3 - ИП
            bool isIndividual = clientTypeId == 1;

            lblINN.Visibility = isIndividual ? Visibility.Collapsed : Visibility.Visible;
            txtINN.Visibility = isIndividual ? Visibility.Collapsed : Visibility.Visible;

            lblOGRN.Visibility = isIndividual ? Visibility.Collapsed : Visibility.Visible;
            txtOGRN.Visibility = isIndividual ? Visibility.Collapsed : Visibility.Visible;

            lblPassportSeries.Visibility = isIndividual ? Visibility.Visible : Visibility.Collapsed;
            txtPassportSeries.Visibility = isIndividual ? Visibility.Visible : Visibility.Collapsed;

            lblPassportNumber.Visibility = isIndividual ? Visibility.Visible : Visibility.Collapsed;
            txtPassportNumber.Visibility = isIndividual ? Visibility.Visible : Visibility.Collapsed;

            lblPassportIssueDate.Visibility = isIndividual ? Visibility.Visible : Visibility.Collapsed;
            dpPassportIssueDate.Visibility = isIndividual ? Visibility.Visible : Visibility.Collapsed;

            lblBirthDate.Visibility = isIndividual ? Visibility.Visible : Visibility.Collapsed;
            dpBirthDate.Visibility = isIndividual ? Visibility.Visible : Visibility.Collapsed;

            lblRepresentativeName.Visibility = isIndividual ? Visibility.Collapsed : Visibility.Visible;
            txtRepresentativeName.Visibility = isIndividual ? Visibility.Collapsed : Visibility.Visible;
        }
    }
}