﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;

namespace PraktikaPM04.SRZ
{
    public partial class ViewGeneratedReportsWindow : Window
    {
        private readonly int _userId;

        public ViewGeneratedReportsWindow(int userId)
        {
            InitializeComponent();
            _userId = userId;
            LoadGeneratedReports();
            this.Title = "Сгенерированные отчеты";
        }

        private void LoadGeneratedReports()
        {
            string query = @"
                SELECT 
                    ri.InstanceID,
                    r.ReportName,
                    u.FullName AS GeneratedBy,
                    ri.ReportingPeriod,
                    ri.GeneratedDate,
                    CASE WHEN ri.IsSubmitted = 1 THEN 'Да' ELSE 'Нет' END AS IsSubmitted,
                    ri.SubmittedDate,
                    ri.FilePath
                FROM ReportInstances ri
                JOIN Reports r ON ri.ReportID = r.ReportID
                JOIN Users u ON ri.GeneratedBy = u.UserID
                WHERE r.ReportID IN (
                    SELECT ReportID FROM Reports 
                    WHERE DepartmentID = 1 -- Служба по работе с заявителями
                    OR DepartmentID IS NULL
                )
                ORDER BY ri.GeneratedDate DESC";

            DataTable reports = DatabaseHelper.ExecuteQuery(query);
            dgGeneratedReports.ItemsSource = reports.DefaultView;
        }

        private void btnOpenReport_Click(object sender, RoutedEventArgs e)
        {
            if (dgGeneratedReports.SelectedItem == null) return;

            DataRowView row = (DataRowView)dgGeneratedReports.SelectedItem;
            string filePath = row["FilePath"]?.ToString();

            if (string.IsNullOrWhiteSpace(filePath))
            {
                MessageBox.Show("Файл отчета не найден", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                System.Diagnostics.Process.Start(filePath);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при открытии отчета: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnMarkAsSubmitted_Click(object sender, RoutedEventArgs e)
        {
            if (dgGeneratedReports.SelectedItem == null) return;

            DataRowView row = (DataRowView)dgGeneratedReports.SelectedItem;
            int instanceId = (int)row["InstanceID"];

            try
            {
                string query = @"
                    UPDATE ReportInstances 
                    SET IsSubmitted = 1, 
                        SubmittedDate = GETDATE()
                    WHERE InstanceID = @InstanceID";

                var parameters = new[] { new SqlParameter("@InstanceID", instanceId) };

                DatabaseHelper.ExecuteNonQuery(query, parameters);

                MessageBox.Show("Отчет помечен как отправленный", "Успех",
                    MessageBoxButton.OK, MessageBoxImage.Information);

                LoadGeneratedReports();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при обновлении отчета: {ex.Message}",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}