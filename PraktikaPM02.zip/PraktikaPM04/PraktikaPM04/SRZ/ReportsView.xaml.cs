﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace PraktikaPM04.SRZ
{
    public partial class ReportsView : UserControl
    {
        private readonly int _userId;

        public ReportsView(int userId)
        {
            InitializeComponent();
            _userId = userId;
            LoadReports();
            this.Tag = "Отчетность";
        }

        private void LoadReports()
        {
            string query = @"
                SELECT 
                    r.ReportID,
                    r.ReportName,
                    d.DepartmentName AS Department,
                    r.Frequency,
                    CASE 
                        WHEN r.Frequency = 'Monthly' THEN CONCAT('День ', r.DueDay)
                        WHEN r.Frequency = 'Quarterly' THEN CONCAT('День ', r.DueDay, ' месяца')
                        ELSE r.Frequency
                    END AS DueDate,
                    r.Description
                FROM Reports r
                LEFT JOIN Departments d ON r.DepartmentID = d.DepartmentID
                WHERE d.DepartmentName = 'Служба по работе с заявителями' OR r.DepartmentID IS NULL
                ORDER BY r.ReportName";

            DataTable reports = DatabaseHelper.ExecuteQuery(query);
            dgReports.ItemsSource = reports.DefaultView;
        }

        private void btnGenerateReport_Click(object sender, RoutedEventArgs e)
        {
            if (dgReports.SelectedItem == null) return;

            DataRowView row = (DataRowView)dgReports.SelectedItem;
            int reportId = (int)row["ReportID"];
            string reportName = row["ReportName"].ToString();

            try
            {
                // Здесь должна быть логика генерации конкретного отчета
                // Для примера просто создаем запись о генерации отчета

                string query = @"
                    INSERT INTO ReportInstances (
                        ReportID, ReportingPeriod, GeneratedBy
                    ) VALUES (
                        @ReportID, @ReportingPeriod, @GeneratedBy
                    )";

                var parameters = new[]
                {
                    new SqlParameter("@ReportID", reportId),
                    new SqlParameter("@ReportingPeriod", DateTime.Today),
                    new SqlParameter("@GeneratedBy", _userId)
                };

                DatabaseHelper.ExecuteNonQuery(query, parameters);

                MessageBox.Show($"Отчет '{reportName}' успешно сгенерирован", "Успех",
                    MessageBoxButton.OK, MessageBoxImage.Information);

                LoadReports();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при генерации отчета: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnViewGenerated_Click(object sender, RoutedEventArgs e)
        {
            var viewWindow = new ViewGeneratedReportsWindow(_userId);
            viewWindow.ShowDialog();
        }

        private void btnRefresh_Click(object sender, RoutedEventArgs e)
        {
            LoadReports();
        }
    }
}