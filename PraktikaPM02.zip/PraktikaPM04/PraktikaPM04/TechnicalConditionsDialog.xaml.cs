﻿using System;
using System.Windows;
using Microsoft.Win32;

namespace PraktikaPM04
{
    public partial class TechnicalConditionsDialog : Window
    {
        public string ConditionsText { get; private set; }
        public string FilePath { get; private set; }

        public TechnicalConditionsDialog()
        {
            InitializeComponent();
        }

        private void BrowseButton_Click(object sender, RoutedEventArgs e)
        {
            var saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "PDF документ (*.pdf)|*.pdf|Word документ (*.docx)|*.docx";
            if (saveFileDialog.ShowDialog() == true)
            {
                FilePathTextBox.Text = saveFileDialog.FileName;
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(ConditionsTextBox.Text))
            {
                MessageBox.Show("Введите текст технических условий", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(FilePathTextBox.Text))
            {
                MessageBox.Show("Укажите путь для сохранения файла", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            ConditionsText = ConditionsTextBox.Text;
            FilePath = FilePathTextBox.Text;
            DialogResult = true;
            Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}