﻿using System.Data;
using System.Data.SqlClient;
using System.Windows;

namespace PraktikaPM04
{
    public partial class DocumentTypeSelectionWindow : Window
    {
        public int SelectedDocumentTypeId { get; private set; }

        public DocumentTypeSelectionWindow()
        {
            InitializeComponent();
            LoadDocumentTypes();
        }

        private void LoadDocumentTypes()
        {
            string query = "SELECT DocumentTypeID, TypeName FROM DocumentTypes ORDER BY TypeName";
            DataTable typesTable = DatabaseHelper.ExecuteQuery(query);
            cmbDocumentTypes.ItemsSource = typesTable.DefaultView;
            cmbDocumentTypes.SelectedIndex = 0;
        }

        private void OK_Click(object sender, RoutedEventArgs e)
        {
            if (cmbDocumentTypes.SelectedValue != null)
            {
                SelectedDocumentTypeId = (int)cmbDocumentTypes.SelectedValue;
                DialogResult = true;
            }
            else
            {
                MessageBox.Show("Выберите тип документа", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}