﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;

namespace PraktikaPM04
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Password;

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                lblErrorMessage.Text = "Введите логин и пароль";
                lblErrorMessage.Visibility = Visibility.Visible;
                return;
            }

            try
            {
                string query = @"
                    SELECT u.UserID, u.FullName, r.RoleName 
                    FROM Users u 
                    JOIN UserRoles ur ON u.UserID = ur.UserID 
                    JOIN Roles r ON ur.RoleID = r.RoleID 
                    WHERE u.Username = @Username AND u.Password = @Password AND u.IsActive = 1";

                var parameters = new[]
                {
                    new SqlParameter("@Username", SqlDbType.NVarChar) { Value = username },
                    new SqlParameter("@Password", SqlDbType.NVarChar) { Value = password }
                };

                DataTable result = DatabaseHelper.ExecuteQuery(query, parameters);

                if (result.Rows.Count > 0)
                {
                    DataRow row = result.Rows[0];
                    int userId = (int)row["UserID"];
                    string fullName = row["FullName"].ToString();
                    string roleName = row["RoleName"].ToString();

                    var mainWindow = new MainWindow(userId, fullName, roleName);
                    mainWindow.Show();
                    this.Close();
                }
                else
                {
                    lblErrorMessage.Text = "Неверный логин или пароль";
                    lblErrorMessage.Visibility = Visibility.Visible;
                }
            }
            catch (Exception ex)
            {
                lblErrorMessage.Text = $"Ошибка: {ex.Message}";
                lblErrorMessage.Visibility = Visibility.Visible;
            }
        }
    }
}