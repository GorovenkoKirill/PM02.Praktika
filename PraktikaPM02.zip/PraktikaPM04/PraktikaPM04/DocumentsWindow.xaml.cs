﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;

namespace PraktikaPM04
{
    public partial class DocumentsWindow : Window
    {
        private int _applicationId;

        public DocumentsWindow(int applicationId)
        {
            InitializeComponent();
            _applicationId = applicationId;
            Loaded += DocumentsWindow_Loaded;
            Title = $"Документы заявки №{applicationId}";
        }

        private void DocumentsWindow_Loaded(object sender, RoutedEventArgs e)
        {
            LoadDocuments();
        }

        private void LoadDocuments()
        {
            try
            {
                string query = @"
                    SELECT 
                        d.DocumentID,
                        dt.TypeName AS DocumentType,
                        d.FilePath,
                        d.IsAttached,
                        d.CreationDate
                    FROM Documents d
                    JOIN DocumentTypes dt ON d.DocumentTypeID = dt.DocumentTypeID
                    WHERE d.ApplicationID = @ApplicationID
                    ORDER BY d.CreationDate DESC";

                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@ApplicationID", _applicationId)
                };

                DataTable dt = DatabaseHelper.ExecuteQuery(query, parameters);
                dgDocuments.ItemsSource = dt.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке документов: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnOpen_Click(object sender, RoutedEventArgs e)
        {
            if (dgDocuments.SelectedItem == null) return;

            DataRowView row = (DataRowView)dgDocuments.SelectedItem;
            string filePath = row["FilePath"].ToString();

            try
            {
                // В реальном приложении здесь будет открытие файла
                MessageBox.Show($"Будет открыт файл: {filePath}", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при открытии файла: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}