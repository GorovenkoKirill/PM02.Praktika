﻿using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;

namespace PraktikaPM04
{
    public partial class ProjectDialog : Window
    {
        public int ApplicationId { get; private set; }
        public string ProjectName { get; private set; }
        public string ProjectCategory { get; private set; }
        public string ProjectDescription { get; private set; }

        public ProjectDialog()
        {
            InitializeComponent();
            LoadApplications();
            ApplicationsComboBox.SelectionChanged += ApplicationsComboBox_SelectionChanged;
            CategoryComboBox.SelectedIndex = 0; // Выбираем первую категорию по умолчанию
        }

        private void LoadApplications()
        {
            try
            {
                string query = @"
                    SELECT a.ApplicationID, c.FullName, a.ObjectName, a.Comments
                    FROM Applications a
                    JOIN Clients c ON a.ClientID = c.ClientID
                    WHERE a.StatusID = 3 -- Рассматривается
                    AND NOT EXISTS (SELECT 1 FROM ConstructionProjects p WHERE p.ApplicationID = a.ApplicationID)
                    ORDER BY a.ApplicationID DESC";

                DataTable applications = DatabaseHelper.ExecuteQuery(query);
                ApplicationsComboBox.ItemsSource = applications.DefaultView;

                if (applications.Rows.Count > 0)
                {
                    ApplicationsComboBox.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки заявок: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ApplicationsComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ApplicationsComboBox.SelectedItem is DataRowView row)
            {
                ClientInfoTextBlock.Text = $"{row["FullName"]} ({row["ObjectName"]})";

                // Автоматически заполняем название проекта
                ProjectNameTextBox.Text = $"Проект газоснабжения {row["ObjectName"]}";

                // Автоматически заполняем описание из комментария заявки
                DescriptionTextBox.Text = row["Comments"].ToString();
            }
        }

        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            if (ApplicationsComboBox.SelectedItem == null)
            {
                MessageBox.Show("Выберите заявку", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(ProjectNameTextBox.Text))
            {
                MessageBox.Show("Введите название проекта", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (CategoryComboBox.SelectedItem == null)
            {
                MessageBox.Show("Выберите категорию проекта", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            ApplicationId = (int)ApplicationsComboBox.SelectedValue;
            ProjectName = ProjectNameTextBox.Text;
            ProjectCategory = (CategoryComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();
            ProjectDescription = DescriptionTextBox.Text;

            DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}