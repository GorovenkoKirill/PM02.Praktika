﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace PraktikaPM04.PTO
{
    public partial class ProcessApplicationsView : UserControl
    {
        private readonly int _userId;

        public ProcessApplicationsView(int userId)
        {
            InitializeComponent();
            _userId = userId;
            LoadData();
            this.Tag = "Обработка заявок";
        }

        private void LoadData()
        {
            try
            {
                // Загрузка статусов заявок
                string statusQuery = "SELECT * FROM ApplicationStatuses";
                DataTable statuses = DatabaseHelper.ExecuteQuery(statusQuery);
                cmbStatus.ItemsSource = statuses.DefaultView;
                cmbStatus.SelectedValuePath = "StatusID";
                cmbNewStatus.ItemsSource = statuses.DefaultView;
                cmbNewStatus.SelectedValuePath = "StatusID";

                // Загрузка типов заявок
                string appTypeQuery = "SELECT * FROM ApplicationTypes";
                DataTable appTypes = DatabaseHelper.ExecuteQuery(appTypeQuery);
                cmbAppType.ItemsSource = appTypes.DefaultView;
                cmbAppType.SelectedValuePath = "ApplicationTypeID";

                // Установка дат по умолчанию
                dpFrom.SelectedDate = DateTime.Now.AddMonths(-1);
                dpTo.SelectedDate = DateTime.Now;

                // Загрузка заявок
                LoadApplications();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LoadApplications()
        {
            string query = @"
                SELECT a.*, at.TypeName, s.StatusName, c.FullName 
                FROM Applications a
                JOIN ApplicationTypes at ON a.ApplicationTypeID = at.ApplicationTypeID
                JOIN ApplicationStatuses s ON a.StatusID = s.StatusID
                JOIN Clients c ON a.ClientID = c.ClientID
                WHERE a.StatusID IN (2, 3) -- В работе или Рассматривается
                ORDER BY a.CreationDate DESC";

            DataTable applications = DatabaseHelper.ExecuteQuery(query);
            dgApplications.ItemsSource = applications.DefaultView;
        }

        private void BtnApplyFilter_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string query = @"
                    SELECT a.*, at.TypeName, s.StatusName, c.FullName 
                    FROM Applications a
                    JOIN ApplicationTypes at ON a.ApplicationTypeID = at.ApplicationTypeID
                    JOIN ApplicationStatuses s ON a.StatusID = s.StatusID
                    JOIN Clients c ON a.ClientID = c.ClientID
                    WHERE 1=1";

                if (cmbStatus.SelectedValue != null)
                    query += $" AND a.StatusID = {cmbStatus.SelectedValue}";

                if (cmbAppType.SelectedValue != null)
                    query += $" AND a.ApplicationTypeID = {cmbAppType.SelectedValue}";

                if (dpFrom.SelectedDate != null)
                    query += $" AND a.CreationDate >= '{dpFrom.SelectedDate.Value:yyyy-MM-dd}'";

                if (dpTo.SelectedDate != null)
                    query += $" AND a.CreationDate <= '{dpTo.SelectedDate.Value:yyyy-MM-dd}'";

                query += " ORDER BY a.CreationDate DESC";

                DataTable applications = DatabaseHelper.ExecuteQuery(query);
                dgApplications.ItemsSource = applications.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при фильтрации: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnResetFilter_Click(object sender, RoutedEventArgs e)
        {
            cmbStatus.SelectedIndex = -1;
            cmbAppType.SelectedIndex = -1;
            dpFrom.SelectedDate = DateTime.Now.AddMonths(-1);
            dpTo.SelectedDate = DateTime.Now;
            LoadApplications();
        }

        private void DgApplications_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dgApplications.SelectedItem == null) return;

            try
            {
                DataRowView row = (DataRowView)dgApplications.SelectedItem;
                int applicationId = (int)row["ApplicationID"];

                // Загрузка документов
                string docsQuery = @"
                    SELECT d.*, dt.TypeName 
                    FROM Documents d
                    JOIN DocumentTypes dt ON d.DocumentTypeID = dt.DocumentTypeID
                    WHERE d.ApplicationID = @ApplicationID";

                var docParam = new SqlParameter("@ApplicationID", SqlDbType.Int) { Value = applicationId };
                DataTable documents = DatabaseHelper.ExecuteQuery(docsQuery, new[] { docParam });
                dgDocuments.ItemsSource = documents.DefaultView;

                // Загрузка истории обработки
                string workflowQuery = @"
                    SELECT w.*, 
                           fd.DepartmentName AS FromDepartmentName,
                           td.DepartmentName AS ToDepartmentName,
                           s.StatusName
                    FROM ApplicationWorkflow w
                    LEFT JOIN Departments fd ON w.FromDepartmentID = fd.DepartmentID
                    JOIN Departments td ON w.ToDepartmentID = td.DepartmentID
                    JOIN ApplicationStatuses s ON w.StatusID = s.StatusID
                    WHERE w.ApplicationID = @ApplicationID
                    ORDER BY w.ActionDate DESC";

                DataTable workflow = DatabaseHelper.ExecuteQuery(workflowQuery, new[] { docParam });
                dgWorkflow.ItemsSource = workflow.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке деталей заявки: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnChangeStatus_Click(object sender, RoutedEventArgs e)
        {
            if (dgApplications.SelectedItem == null || cmbNewStatus.SelectedValue == null)
            {
                MessageBox.Show("Выберите заявку и новый статус", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                DataRowView row = (DataRowView)dgApplications.SelectedItem;
                int applicationId = (int)row["ApplicationID"];
                int newStatusId = (int)cmbNewStatus.SelectedValue;
                string comments = txtStatusComment.Text;

                // Получаем текущий отдел пользователя
                string deptQuery = "SELECT DepartmentID FROM Users WHERE UserID = @UserID";
                var deptParam = new SqlParameter("@UserID", SqlDbType.Int) { Value = _userId };
                DataTable deptResult = DatabaseHelper.ExecuteQuery(deptQuery, new[] { deptParam });

                if (deptResult.Rows.Count == 0)
                {
                    MessageBox.Show("Не удалось определить отдел пользователя", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                int fromDeptId = (int)deptResult.Rows[0]["DepartmentID"];
                int toDeptId = fromDeptId; // По умолчанию - остается в том же отделе

                // Определяем следующий отдел в зависимости от нового статуса
                if (newStatusId == 3) // Рассматривается - передаем в ПСО
                {
                    toDeptId = 3; // ID ПСО
                }
                else if (newStatusId == 4) // Одобрена - передаем в ОКС
                {
                    toDeptId = 4; // ID ОКС
                }

                // Обновляем статус заявки
                string updateQuery = "UPDATE Applications SET StatusID = @StatusID, ModificationDate = GETDATE() WHERE ApplicationID = @ApplicationID";
                var updateParams = new[]
                {
                    new SqlParameter("@StatusID", SqlDbType.Int) { Value = newStatusId },
                    new SqlParameter("@ApplicationID", SqlDbType.Int) { Value = applicationId }
                };
                DatabaseHelper.ExecuteNonQuery(updateQuery, updateParams);

                // Добавляем запись в историю workflow
                string workflowQuery = @"
                    INSERT INTO ApplicationWorkflow (
                        ApplicationID, FromDepartmentID, ToDepartmentID, StatusID, 
                        ActionDate, Comments, ProcessingDeadline, DeadlineDate
                    ) VALUES (
                        @ApplicationID, @FromDepartmentID, @ToDepartmentID, @StatusID,
                        GETDATE(), @Comments, 5, DATEADD(day, 5, GETDATE())
                    )";

                var workflowParams = new[]
                {
                    new SqlParameter("@ApplicationID", SqlDbType.Int) { Value = applicationId },
                    new SqlParameter("@FromDepartmentID", SqlDbType.Int) { Value = fromDeptId },
                    new SqlParameter("@ToDepartmentID", SqlDbType.Int) { Value = toDeptId },
                    new SqlParameter("@StatusID", SqlDbType.Int) { Value = newStatusId },
                    new SqlParameter("@Comments", SqlDbType.NVarChar) { Value = comments ?? (object)DBNull.Value }
                };
                DatabaseHelper.ExecuteNonQuery(workflowQuery, workflowParams);

                MessageBox.Show("Статус заявки успешно изменен", "Успех",
                    MessageBoxButton.OK, MessageBoxImage.Information);

                // Обновляем данные
                DgApplications_SelectionChanged(null, null);
                LoadApplications();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при изменении статуса: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnCreateTechnicalConditions_Click(object sender, RoutedEventArgs e)
        {
            if (dgApplications.SelectedItem == null || string.IsNullOrWhiteSpace(txtConditions.Text))
            {
                MessageBox.Show("Выберите заявку и введите текст технических условий", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                DataRowView row = (DataRowView)dgApplications.SelectedItem;
                int applicationId = (int)row["ApplicationID"];
                string conditionsText = txtConditions.Text;

                // Сначала создаем запись в документах
                string docQuery = @"
                    INSERT INTO Documents (ApplicationID, DocumentTypeID, FilePath, IsAttached)
                    VALUES (@ApplicationID, 4, NULL, 0);
                    SELECT SCOPE_IDENTITY();";

                var docParams = new[]
                {
                    new SqlParameter("@ApplicationID", SqlDbType.Int) { Value = applicationId }
                };

                int documentId = Convert.ToInt32(DatabaseHelper.ExecuteScalar(docQuery, docParams));

                // Затем создаем технические условия
                string tcQuery = @"
                    INSERT INTO TechnicalConditions (
                        ApplicationID, DocumentID, ConditionsText, IsApproved, ApprovalDate, ApprovedBy
                    ) VALUES (
                        @ApplicationID, @DocumentID, @ConditionsText, 0, NULL, NULL
                    )";

                var tcParams = new[]
                {
                    new SqlParameter("@ApplicationID", SqlDbType.Int) { Value = applicationId },
                    new SqlParameter("@DocumentID", SqlDbType.Int) { Value = documentId },
                    new SqlParameter("@ConditionsText", SqlDbType.NVarChar) { Value = conditionsText }
                };

                DatabaseHelper.ExecuteNonQuery(tcQuery, tcParams);

                MessageBox.Show("Технические условия успешно созданы", "Успех",
                    MessageBoxButton.OK, MessageBoxImage.Information);

                // Обновляем список документов
                DgApplications_SelectionChanged(null, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при создании технических условий: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnViewDocument_Click(object sender, RoutedEventArgs e)
        {
            if (dgDocuments.SelectedItem == null)
            {
                MessageBox.Show("Выберите документ для просмотра", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                DataRowView row = (DataRowView)dgDocuments.SelectedItem;
                string filePath = row["FilePath"] as string;

                if (string.IsNullOrEmpty(filePath))
                {
                    MessageBox.Show("Документ не прикреплен", "Информация",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                // В реальном приложении здесь был бы код для открытия файла
                MessageBox.Show($"Будет открыт документ: {filePath}", "Информация",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при открытии документа: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}