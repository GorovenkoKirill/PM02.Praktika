﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace PraktikaPM04.PTO
{
    public partial class TechnicalConditionsView : UserControl
    {
        private readonly int _userId;

        public TechnicalConditionsView(int userId)
        {
            InitializeComponent();
            _userId = userId;
            LoadData();
            this.Tag = "Технические условия";
        }

        private void LoadData()
        {
            try
            {
                // Установка дат по умолчанию
                dpFrom.SelectedDate = DateTime.Now.AddMonths(-1);
                dpTo.SelectedDate = DateTime.Now;

                // Загрузка технических условий
                LoadTechnicalConditions();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LoadTechnicalConditions()
        {
            string query = @"
                SELECT tc.*, a.ObjectName, c.FullName, 
                       CASE WHEN tc.IsApproved = 1 THEN 'Утверждено' ELSE 'Неутверждено' END AS StatusText,
                       d.CreationDate
                FROM TechnicalConditions tc
                JOIN Applications a ON tc.ApplicationID = a.ApplicationID
                JOIN Clients c ON a.ClientID = c.ClientID
                LEFT JOIN Documents d ON tc.DocumentID = d.DocumentID
                ORDER BY d.CreationDate DESC";

            DataTable conditions = DatabaseHelper.ExecuteQuery(query);
            dgConditions.ItemsSource = conditions.DefaultView;
        }

        private void BtnApplyFilter_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string query = @"
                    SELECT tc.*, a.ObjectName, c.FullName, 
                           CASE WHEN tc.IsApproved = 1 THEN 'Утверждено' ELSE 'Неутверждено' END AS StatusText,
                           d.CreationDate
                    FROM TechnicalConditions tc
                    JOIN Applications a ON tc.ApplicationID = a.ApplicationID
                    JOIN Clients c ON a.ClientID = c.ClientID
                    LEFT JOIN Documents d ON tc.DocumentID = d.DocumentID
                    WHERE 1=1";

                if (cmbStatus.SelectedIndex == 1) // Неутвержденные
                    query += " AND tc.IsApproved = 0";
                else if (cmbStatus.SelectedIndex == 2) // Утвержденные
                    query += " AND tc.IsApproved = 1";

                if (dpFrom.SelectedDate != null)
                    query += $" AND d.CreationDate >= '{dpFrom.SelectedDate.Value:yyyy-MM-dd}'";

                if (dpTo.SelectedDate != null)
                    query += $" AND d.CreationDate <= '{dpTo.SelectedDate.Value:yyyy-MM-dd}'";

                query += " ORDER BY d.CreationDate DESC";

                DataTable conditions = DatabaseHelper.ExecuteQuery(query);
                dgConditions.ItemsSource = conditions.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при фильтрации: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnResetFilter_Click(object sender, RoutedEventArgs e)
        {
            cmbStatus.SelectedIndex = 0;
            dpFrom.SelectedDate = DateTime.Now.AddMonths(-1);
            dpTo.SelectedDate = DateTime.Now;
            LoadTechnicalConditions();
        }

        private void DgConditions_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dgConditions.SelectedItem == null) return;

            try
            {
                DataRowView row = (DataRowView)dgConditions.SelectedItem;
                bool isApproved = (bool)row["IsApproved"];
                chkApprove.IsChecked = isApproved;
                chkApprove.IsEnabled = !isApproved;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке деталей ТУ: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnApproveConditions_Click(object sender, RoutedEventArgs e)
        {
            if (dgConditions.SelectedItem == null || !chkApprove.IsChecked.HasValue || !chkApprove.IsChecked.Value)
            {
                MessageBox.Show("Выберите ТУ и подтвердите утверждение", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                DataRowView row = (DataRowView)dgConditions.SelectedItem;
                int conditionId = (int)row["ConditionID"];
                string comment = txtApprovalComment.Text;

                // Получаем имя пользователя
                string userQuery = "SELECT FullName FROM Users WHERE UserID = @UserID";
                var userParam = new SqlParameter("@UserID", SqlDbType.Int) { Value = _userId };
                DataTable userResult = DatabaseHelper.ExecuteQuery(userQuery, new[] { userParam });

                if (userResult.Rows.Count == 0)
                {
                    MessageBox.Show("Не удалось определить пользователя", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                string approvedBy = userResult.Rows[0]["FullName"].ToString();

                // Обновляем ТУ
                string updateQuery = @"
                    UPDATE TechnicalConditions 
                    SET IsApproved = 1, 
                        ApprovalDate = GETDATE(), 
                        ApprovedBy = @ApprovedBy
                    WHERE ConditionID = @ConditionID";

                var updateParams = new[]
                {
                    new SqlParameter("@ApprovedBy", SqlDbType.NVarChar) { Value = approvedBy },
                    new SqlParameter("@ConditionID", SqlDbType.Int) { Value = conditionId }
                };
                DatabaseHelper.ExecuteNonQuery(updateQuery, updateParams);

                MessageBox.Show("Технические условия успешно утверждены", "Успех",
                    MessageBoxButton.OK, MessageBoxImage.Information);

                // Обновляем данные
                LoadTechnicalConditions();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при утверждении ТУ: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnExportToWord_Click(object sender, RoutedEventArgs e)
        {
            if (dgConditions.SelectedItem == null)
            {
                MessageBox.Show("Выберите технические условия для экспорта", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                DataRowView row = (DataRowView)dgConditions.SelectedItem;
                int applicationId = (int)row["ApplicationID"];
                string objectName = row["ObjectName"].ToString();
                string conditionsText = row["ConditionsText"].ToString();

                // В реальном приложении здесь был бы код для экспорта в Word
                MessageBox.Show($"Будет экспортировано ТУ для заявки №{applicationId} ({objectName})", "Информация",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при экспорте в Word: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}