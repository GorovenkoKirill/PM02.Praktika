﻿using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;

namespace PraktikaPM04.PTO
{
    public partial class ReportsView : UserControl
    {
        public ReportsView()
        {
            InitializeComponent();
            LoadReports();
            this.Tag = "Отчетность ПТО";
        }

        private void LoadReports()
        {
            try
            {
                string query = @"
                    SELECT ReportName, Frequency, 
                           CASE 
                               WHEN DueDay IS NOT NULL AND DueMonth IS NULL THEN 'До ' + CAST(DueDay AS VARCHAR) + ' числа'
                               WHEN DueDay IS NOT NULL AND DueMonth IS NOT NULL THEN 'До ' + CAST(DueDay AS VARCHAR) + '.' + CAST(DueMonth AS VARCHAR)
                               ELSE 'По требованию'
                           END AS DueDay
                    FROM Reports
                    WHERE DepartmentID = 2 -- ПТО
                    ORDER BY ReportName";

                DataTable reports = DatabaseHelper.ExecuteQuery(query);
                dgReports.ItemsSource = reports.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке отчетов: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnGenerateReport_Click(object sender, RoutedEventArgs e)
        {
            if (dgReports.SelectedItem == null)
            {
                MessageBox.Show("Выберите отчет для формирования", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                DataRowView row = (DataRowView)dgReports.SelectedItem;
                string reportName = row["ReportName"].ToString();

                // В реальном приложении здесь должен быть код для формирования отчета
                MessageBox.Show($"Будет сформирован отчет: {reportName}", "Информация",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при формировании отчета: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}