﻿using System.Windows;

namespace PraktikaPM04
{
    public partial class SurveyTaskDialog : Window
    {
        public string CompanyName => CompanyTextBox.Text;
        public string Comments => CommentsTextBox.Text;

        public SurveyTaskDialog()
        {
            InitializeComponent();
        }

        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(CompanyName))
            {
                MessageBox.Show("Введите название компании-исполнителя", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DialogResult = true;
        }
    }
}