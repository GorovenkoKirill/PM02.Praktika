﻿using System;
using System.Windows;

namespace PraktikaPM04
{
    public partial class WorkActDialog : Window
    {
        public DateTime ActDate => ActDatePicker.SelectedDate ?? DateTime.Now;
        public DateTime ConnectionDate => ConnectionDatePicker.SelectedDate ?? DateTime.Now;

        public WorkActDialog()
        {
            InitializeComponent();
            ActDatePicker.SelectedDate = DateTime.Now;
            ConnectionDatePicker.SelectedDate = DateTime.Now;
        }

        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            if (ActDatePicker.SelectedDate == null || ConnectionDatePicker.SelectedDate == null)
            {
                MessageBox.Show("Выберите даты акта и подключения", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (ConnectionDate < ActDate)
            {
                MessageBox.Show("Дата подключения не может быть раньше даты акта", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DialogResult = true;
        }
    }
}