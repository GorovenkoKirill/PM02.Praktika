﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace PraktikaPM04
{
    public partial class DesignerWindow : UserControl
    {
        private readonly int _userId;
        private string _currentDateTime = DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss");
        private string _statusMessage = "Готово";

        public string CurrentDateTime
        {
            get => _currentDateTime;
            set
            {
                _currentDateTime = value;
                StatusMessage = $"Обновлено: {value}";
            }
        }

        public string StatusMessage
        {
            get => _statusMessage;
            set
            {
                _statusMessage = value;
                DataContext = this;
            }
        }


        public DesignerWindow(int userId)
        {
            _userId = userId;

            InitializeComponent();
            DataContext = this;

            LoadProjects();
            InitializeTimer();
        }

        private void InitializeTimer()
        {
            var timer = new System.Windows.Threading.DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += (s, e) => CurrentDateTime = DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss");
            timer.Start();
        }

        private void LoadProjects()
        {
            try
            {
                string query = @"
            SELECT p.ProjectID, p.ApplicationID, p.ProjectName, 
                   CASE 
                       WHEN a.ApplicationTypeID = 1 AND a.Comments LIKE '%1 кат%' THEN '1 категория'
                       WHEN a.ApplicationTypeID = 1 AND (a.Comments LIKE '%2 кат%' OR a.Comments LIKE '%3 кат%') THEN '2-3 категория'
                       WHEN a.ApplicationTypeID = 1 AND a.Comments LIKE '%ИП%' THEN 'ИП'
                       ELSE 'Не определено'
                   END AS Category,
                   CASE 
                       WHEN a.ApplicationTypeID = 1 AND a.Comments LIKE '%1 кат%' THEN 5
                       WHEN a.ApplicationTypeID = 1 AND (a.Comments LIKE '%2 кат%' OR a.Comments LIKE '%3 кат%') THEN 15
                       WHEN a.ApplicationTypeID = 1 AND a.Comments LIKE '%ИП%' THEN 15
                       ELSE 10
                   END AS DeadlineDays,
                   p.StartDate, 
                   DATEADD(day, 
                       CASE 
                           WHEN a.ApplicationTypeID = 1 AND a.Comments LIKE '%1 кат%' THEN 5
                           WHEN a.ApplicationTypeID = 1 AND (a.Comments LIKE '%2 кат%' OR a.Comments LIKE '%3 кат%') THEN 15
                           WHEN a.ApplicationTypeID = 1 AND a.Comments LIKE '%ИП%' THEN 15
                           ELSE 10
                       END, p.StartDate) AS DeadlineDate,
                   s.StatusName AS Status,
                   CASE 
                       WHEN DATEDIFF(day, GETDATE(), DATEADD(day, 
                           CASE 
                               WHEN a.ApplicationTypeID = 1 AND a.Comments LIKE '%1 кат%' THEN 5
                               WHEN a.ApplicationTypeID = 1 AND (a.Comments LIKE '%2 кат%' OR a.Comments LIKE '%3 кат%') THEN 15
                               WHEN a.ApplicationTypeID = 1 AND a.Comments LIKE '%ИП%' THEN 15
                               ELSE 10
                           END, p.StartDate)) <= 3 THEN 1
                       ELSE 0
                   END AS IsUrgent
            FROM ConstructionProjects p
            JOIN Applications a ON p.ApplicationID = a.ApplicationID
            JOIN ApplicationStatuses s ON a.StatusID = s.StatusID
            WHERE a.StatusID IN (3, 4) -- Рассматривается или Одобрена
            ORDER BY DeadlineDate ASC";

                DataTable projects = DatabaseHelper.ExecuteQuery(query);
                ProjectsGrid.ItemsSource = projects.DefaultView;

                ProjectsGrid.LoadingRow += (s, e) =>
                {
                    DataRowView rowView = e.Row.Item as DataRowView;
                    if (rowView != null && rowView["IsUrgent"] != DBNull.Value && (int)rowView["IsUrgent"] == 1)
                    {
                        e.Row.Background = System.Windows.Media.Brushes.LightPink;
                    }
                };
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка загрузки проектов: {ex.Message}";
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LoadEstimateItems(int projectId)
        {
            try
            {
                string query = @"
                    SELECT ItemID, ApplicationID, ItemNumber, ItemName, Unit, Quantity, UnitPrice
                    FROM EstimateItems
                    WHERE ApplicationID = (SELECT ApplicationID FROM ConstructionProjects WHERE ProjectID = @ProjectID)
                    ORDER BY ItemNumber";

                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@ProjectID", projectId)
                };

                DataTable items = DatabaseHelper.ExecuteQuery(query, parameters);
                EstimateItemsGrid.ItemsSource = items.DefaultView;
                CalculateTotal();
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка загрузки позиций сметы: {ex.Message}";
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CalculateTotal()
        {
            decimal total = 0;
            if (EstimateItemsGrid.ItemsSource != null)
            {
                foreach (DataRowView row in EstimateItemsGrid.Items)
                {
                    if (row["TotalPrice"] != DBNull.Value)
                    {
                        total += Convert.ToDecimal(row["TotalPrice"]);
                    }
                }
            }
            TotalAmountTextBox.Text = total.ToString("N2");
        }

        private void RefreshProjects(object sender, RoutedEventArgs e)
        {
            LoadProjects();
            StatusMessage = "Список проектов обновлен";
        }

        private void CreateProject(object sender, RoutedEventArgs e)
        {
            var dialog = new ProjectDialog();
            if (dialog.ShowDialog() == true)
            {
                try
                {
                    string query = @"
                        INSERT INTO ConstructionProjects (ApplicationID, ProjectName, StartDate)
                        VALUES (@ApplicationID, @ProjectName, GETDATE())";

                    SqlParameter[] parameters = new SqlParameter[]
                    {
                        new SqlParameter("@ApplicationID", dialog.ApplicationId),
                        new SqlParameter("@ProjectName", dialog.ProjectName)
                    };

                    DatabaseHelper.ExecuteNonQuery(query, parameters);
                    LoadProjects();
                    StatusMessage = "Проект создан";
                }
                catch (Exception ex)
                {
                    StatusMessage = $"Ошибка создания проекта: {ex.Message}";
                    MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void SendForApproval(object sender, RoutedEventArgs e)
        {
            if (ProjectsGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите проект для отправки на согласование", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DataRowView row = (DataRowView)ProjectsGrid.SelectedItem;
            int projectId = (int)row["ProjectID"];
            int applicationId = (int)row["ApplicationID"];

            try
            {
                // Обновляем статус заявки
                string updateQuery = @"
                    UPDATE Applications 
                    SET StatusID = 4, -- Одобрена
                        ModificationDate = GETDATE()
                    WHERE ApplicationID = @ApplicationID";

                SqlParameter[] updateParams = new SqlParameter[]
                {
                    new SqlParameter("@ApplicationID", applicationId)
                };

                DatabaseHelper.ExecuteNonQuery(updateQuery, updateParams);

                // Создаем workflow для ПТО
                string workflowQuery = @"
                    INSERT INTO ApplicationWorkflow (ApplicationID, FromDepartmentID, ToDepartmentID, StatusID, 
                                                    ActionDate, Comments, ProcessingDeadline, DeadlineDate)
                    VALUES (@ApplicationID, 3, 2, 4, GETDATE(), 'Проект на согласование', 3, DATEADD(day, 3, GETDATE()))";

                SqlParameter[] workflowParams = new SqlParameter[]
                {
                    new SqlParameter("@ApplicationID", applicationId)
                };

                DatabaseHelper.ExecuteNonQuery(workflowQuery, workflowParams);

                LoadProjects();
                StatusMessage = $"Проект {projectId} отправлен на согласование в ПТО";
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка отправки проекта: {ex.Message}";
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void RefreshEstimates(object sender, RoutedEventArgs e)
        {
            if (ProjectsGrid.SelectedItem != null)
            {
                DataRowView row = (DataRowView)ProjectsGrid.SelectedItem;
                int projectId = (int)row["ProjectID"];
                LoadEstimateItems(projectId);
                StatusMessage = "Смета обновлена";
            }
        }

        private void AddEstimateItem(object sender, RoutedEventArgs e)
        {
            if (ProjectsGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите проект для добавления позиции", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DataRowView projectRow = (DataRowView)ProjectsGrid.SelectedItem;
            int applicationId = (int)projectRow["ApplicationID"];

            var dialog = new EstimateItemDialog();
            if (dialog.ShowDialog() == true)
            {
                try
                {
                    // Получаем следующий номер позиции
                    string maxNumberQuery = @"
                        SELECT ISNULL(MAX(ItemNumber), 0) + 1 
                        FROM EstimateItems 
                        WHERE ApplicationID = @ApplicationID";

                    SqlParameter[] maxNumberParams = new SqlParameter[]
                    {
                        new SqlParameter("@ApplicationID", applicationId)
                    };

                    int nextNumber = Convert.ToInt32(DatabaseHelper.ExecuteScalar(maxNumberQuery, maxNumberParams));

                    // Добавляем новую позицию
                    string insertQuery = @"
                        INSERT INTO EstimateItems (ApplicationID, ItemNumber, ItemName, Unit, Quantity, UnitPrice)
                        VALUES (@ApplicationID, @ItemNumber, @ItemName, @Unit, @Quantity, @UnitPrice)";

                    SqlParameter[] insertParams = new SqlParameter[]
                    {
                        new SqlParameter("@ApplicationID", applicationId),
                        new SqlParameter("@ItemNumber", nextNumber),
                        new SqlParameter("@ItemName", dialog.ItemName),
                        new SqlParameter("@Unit", dialog.Unit),
                        new SqlParameter("@Quantity", dialog.Quantity),
                        new SqlParameter("@UnitPrice", dialog.UnitPrice)
                    };

                    DatabaseHelper.ExecuteNonQuery(insertQuery, insertParams);
                    LoadEstimateItems((int)projectRow["ProjectID"]);
                    StatusMessage = "Позиция добавлена в смету";
                }
                catch (Exception ex)
                {
                    StatusMessage = $"Ошибка добавления позиции: {ex.Message}";
                    MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void RemoveEstimateItem(object sender, RoutedEventArgs e)
        {
            if (EstimateItemsGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите позицию для удаления", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DataRowView row = (DataRowView)EstimateItemsGrid.SelectedItem;
            int itemId = (int)row["ItemID"];

            try
            {
                string query = "DELETE FROM EstimateItems WHERE ItemID = @ItemID";
                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@ItemID", itemId)
                };

                DatabaseHelper.ExecuteNonQuery(query, parameters);
                LoadEstimateItems((int)((DataRowView)ProjectsGrid.SelectedItem)["ProjectID"]);
                StatusMessage = "Позиция удалена из сметы";
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка удаления позиции: {ex.Message}";
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void SaveEstimate(object sender, RoutedEventArgs e)
        {
            if (ProjectsGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите проект для сохранения сметы", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DataRowView projectRow = (DataRowView)ProjectsGrid.SelectedItem;
            int projectId = (int)projectRow["ProjectID"];

            try
            {
                // Обновляем стоимость проекта
                string updateQuery = @"
                    UPDATE ConstructionProjects 
                    SET ProjectCost = (SELECT SUM(Quantity * UnitPrice) FROM EstimateItems WHERE ApplicationID = 
                                      (SELECT ApplicationID FROM ConstructionProjects WHERE ProjectID = @ProjectID))
                    WHERE ProjectID = @ProjectID";

                SqlParameter[] parameters = new SqlParameter[]
                {
                    new SqlParameter("@ProjectID", projectId)
                };

                DatabaseHelper.ExecuteNonQuery(updateQuery, parameters);
                LoadProjects();
                StatusMessage = "Смета сохранена";
            }
            catch (Exception ex)
            {
                StatusMessage = $"Ошибка сохранения сметы: {ex.Message}";
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

    }
}