﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace PraktikaPM04
{
    public static class DatabaseHelper
    {
        public static string ConnectionString { get; } = ConfigurationManager.ConnectionStrings["UnifiedWindowDB"].ConnectionString;

        public static DataTable ExecuteQuery(string query, SqlParameter[] parameters = null)
        {
            DataTable dataTable = new DataTable();

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                if (parameters != null)
                {
                    command.Parameters.AddRange(parameters);
                }

                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(dataTable);
            }

            return dataTable;
        }

        public static int ExecuteNonQuery(string query, SqlParameter[] parameters = null)
        {
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                if (parameters != null)
                {
                    command.Parameters.AddRange(parameters);
                }

                connection.Open();
                return command.ExecuteNonQuery();
            }
        }

        public static object ExecuteScalar(string query, SqlParameter[] parameters = null)
        {
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                if (parameters != null)
                {
                    command.Parameters.AddRange(parameters);
                }

                connection.Open();
                return command.ExecuteScalar();
            }
        }

        public static bool ValidateUser(string username, string password)
        {
            string query = "SELECT COUNT(*) FROM Users WHERE Username = @Username AND Password = @Password";

            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@Username", username),
                new SqlParameter("@Password", password)
            };

            int count = Convert.ToInt32(ExecuteScalar(query, parameters));
            return count > 0;
        }

        public static DataRow GetUserInfo(string username)
        {
            string query = @"SELECT u.*, r.RoleName 
                            FROM Users u
                            JOIN UserRoles ur ON u.UserID = ur.UserID
                            JOIN Roles r ON ur.RoleID = r.RoleID
                            WHERE u.Username = @Username";

            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@Username", username)
            };

            DataTable result = ExecuteQuery(query, parameters);
            return result.Rows.Count > 0 ? result.Rows[0] : null;
        }

    }
}